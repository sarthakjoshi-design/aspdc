# PausePay — Hackathon Judge Guide & Pitch Deck Companion

## 1. The 60–90 Second Live Demonstration Script

**Speaker Setup:** Open PausePay on desktop or mobile (`http://localhost:3000`).

### Step 1: The Everyday Decision (0–15s)
> *"Judges, over 10 billion UPI transactions happen every month in India. But every day, thousands of ordinary citizens—our parents, local shopkeepers, and students—are tricked into losing money because they are told: 'Enter your UPI PIN to claim your cashback.' Once that PIN is entered, the money is gone forever. This is PausePay: Stop. Verify. Then Pay."*

### Step 2: Show Normal Payment Context (15–30s)
> *"Let's test normal behavior. I click 'Grocery (Normal)'. Notice PausePay recognizes my intent is to send money to a grocery store. The score is 0/100—Lower Detected Risk. Crucially, it does NOT raise false alarms just because banking words appear, but still gives a calm pre-payment checklist."*

### Step 3: Trigger the Critical PIN-to-Receive Scam (30–50s)
> *"Now, watch what happens when a scammer sends: 'Congratulations! You won ₹5,000. Scan this QR code and enter your UPI PIN within 5 minutes.' I click 'Cashback Scam'. Immediately, the PausePay Safety Interrupt fires with a clear red alert: 'STOP — Do Not Enter Your UPI PIN'. It gives three unmistakable actions, educates the user that receiving money NEVER requires a PIN, and provides one-click access to the National 1930 Cyber Helpline."*

### Step 4: Show Explainability & "What Changed?" (50–70s)
> *"Judges, we hate black-box AI that says 'Trust us, it's fraud.' When I click 'Why this result?', PausePay shows exact, traceable quotes from the message—the PIN trap override (+95), the urgency deadline (+15), and the QR payment direction mismatch (+25). In our 'What Changed?' simulator, judges can see how changing even a single word alters the detected signals in real time."*

### Step 5: Privacy, Accessibility & Impact (70–90s)
> *"All analysis runs 100% on-device in browser memory—zero telemetry, zero credentials stored. We support audio read-aloud for non-technical users and trilingual interfaces in English, Hindi, and Gujarati. 12 automated unit tests verify every edge case. With PausePay, one pause prevents a costly mistake. Thank you!"*

---

## 2. Judge Question & Answer Bank

### Q1: What problem does your solution actually solve?
**A:** PausePay solves the critical cognitive moment **before** a user authorizes an unsafe payment. In UPI, victims are psychologically manipulated by fake cashback, panic KYC threats, or QR collect requests. By evaluating user intention and detecting dangerous instructions before PIN entry, PausePay interrupts the attack before financial loss occurs.

### Q2: How is PausePay different from a generic keyword detector?
**A:** Traditional keyword filters flag words like "UPI PIN" indiscriminately. PausePay is **intent-aware**:
- Mentioning UPI PIN to *authorize* an outgoing merchant payment is recognized as standard payment flow (Score: 0).
- Demanding a UPI PIN to *receive* money or asking someone to *share* an OTP triggers a mandatory **Critical Override** (Score: 100).
- An unfamiliar recipient alone produces proportionate caution (send ₹1 first), not an unjustified fraud accusation.

### Q3: Why should users and judges trust its risk score?
**A:** It is not a black-box probability or hallucinated AI confidence score. It is an **explainable, deterministic rule engine**. Every point in the score is tied to an explicit, observable evidence quote from the input, displayed transparently in the "Why this result?" breakdown drawer.

### Q4: How does it handle false positives?
**A:** Through:
1. Intent categorization: distinguishing send vs receive vs verify.
2. Contextual exceptions: recognizing words like "authorize payment" or "app will ask for PIN" as normal payment flow.
3. Rule deduplication: repeated urgent words cannot stack score arbitrarily beyond 100.
4. Distinguishing warnings: "Never share OTP" is parsed as security advice, not a credential demand.

### Q5: What if a fraud message contains no obvious warning signs?
**A:** We make this limitation explicit on every single screen: *"Risk indicators were not detected. This does not guarantee that the request is legitimate."* Attackers can craft polite, error-free messages. Therefore, PausePay never labels a transaction "100% Verified Safe"—it always provides the 5-step Pre-Payment Checklist.

### Q6: How does PausePay analyze QR codes?
**A:** Local QR decoding uses a browser canvas and `jsqr`. When decoded, PausePay parses the NPCI `upi://pay` URI scheme to extract Payee VPA (`pa`), Payee Name (`pn`), preset Amount (`am`), and Note (`tn`). If the user intended to *receive* money, but the QR payload contains an *outgoing payment request*, PausePay flags a **Payment Direction Mismatch**.

### Q7: Does PausePay access real UPI transactions or bank accounts?
**A:** No. PausePay is deliberately designed as a **privacy-first zero-telemetry prototype**. It does not connect to bank APIs, does not collect passwords or PINs, and does not execute financial transactions. All data stays inside the user's browser memory.

### Q8: Why did you use deterministic rule-based analysis rather than an LLM API?
**A:** Financial safety requires **instantaneous, 100% reliable, zero-latency, offline verification**. An external cloud LLM introduces privacy risks (sending private SMS/QR to third-party servers), API latency, hallucinations, and costs. Our deterministic engine runs offline in milliseconds and passed 100% of our test suite. In production, lightweight on-device Small Language Models (SLMs) can complement this engine without external data leakage.

### Q9: How would you evaluate the system using labeled datasets in the future?
**A:** We would benchmark the engine against real anonymized fraud datasets from cybercrime cells (e.g., I4C / CERT-In) and legitimate transaction logs, measuring precision, recall, and false positive rates across diverse Indian languages and regional dialects.

### Q10: What would be required to deploy a reliable production version?
**A:** 
1. Android Accessibility Service or Keyboard Extension integration to inspect payment screens in real time.
2. NPCI verified merchant registry integration.
3. Strict security audit and privacy compliance with India's Digital Personal Data Protection (DPDP) Act.

---

## 3. Automated Test Verification Record

Ran with `node --test src/engine/riskEngine.test.ts`:
```
✔ Test 1: Ordinary merchant payment produces low risk without fraud alerts (5.3ms)
✔ Test 2: PIN-to-receive scam triggers critical override and clear advice (3.4ms)
✔ Test 3: Credential disclosure demand triggers critical risk (3.3ms)
✔ Test 4: Urgent bank impersonation detects suspension threat and urgency without fabricating URLs (0.7ms)
✔ Test 5: Suspicious shortened link and reward bait are correctly flagged (2.8ms)
✔ Test 6: Unknown recipient alone produces modest verification warning, not fraud accusation (0.5ms)
✔ Test 7: Normal payment authorization mentioning PIN does NOT trigger PIN-to-receive override (0.3ms)
✔ Test 8: Remote-access software paired with banking triggers strong warning (0.7ms)
✔ Test 9: Malformed link handles cleanly without crashing (1.7ms)
✔ Test 10: Legitimate-looking UPI QR payload extracts payee and amount with honesty limitations (0.8ms)
✔ Test 11: Empty input handles cleanly without throwing or fabricating scores (0.3ms)
✔ Test 12: Deduplication and score bounds strictly adhere to 0-100 range (0.5ms)

12 passed, 0 failed, 12 total. Duration: 296ms.
```
