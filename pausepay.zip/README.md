# PausePay — Stop Fraud Before Payment

> **Tagline:** Stop. Verify. Then Pay.  
> **Supporting message:** "One pause can prevent a costly mistake."  
> **Primary CTA:** Analyze a Payment | **Helpline:** Dial 1930 (Indian Cyber Financial Fraud)

PausePay is a privacy-first, intent-aware UPI cybersecurity assistant that evaluates suspicious payment messages, collect requests, phishing links, and QR codes *before* a user authorizes a transaction.

Built for hackathon demonstration with **zero external AI dependencies**, **zero telemetry**, and **100% on-device deterministic heuristics**.

---

## 1. Core Problem Statement

UPI fraud in India frequently tricks ordinary users, seniors, and non-technical citizens through:
- **PIN-to-Receive Scams:** Conning victims into believing entering a UPI PIN will "receive" or "claim" cashback.
- **Collect Request Traps:** Sending high-value collect requests masked as refunds.
- **QR Code Misdirection:** Sending a `upi://pay` QR code to an online seller saying "scan to accept payment."
- **Urgent Account Block Threat:** Threatening immediate bank account suspension or power disconnection within 10 minutes.
- **Remote-Access Takeover:** Demanding installation of AnyDesk or TeamViewer during banking activity.

Traditional antivirus or spam filters flag spam keywords generically without understanding **the user's payment intention**.

---

## 2. Four Signature Innovations

### Feature A: Intent-Aware Safety Engine
PausePay asks: **What are you trying to do?**
- *Sending money* vs *Receiving money* vs *Scanning QR* vs *Verifying SMS*
- **Critical Semantic Context:** If a user is paying a merchant and mentions their app asks for a PIN to authorize payment, this is **normal payment behavior** (Score: <15). However, if a message promises ₹5,000 and tells the user to enter their PIN to receive it, PausePay flags this as a **CRITICAL FRAUD TRAP** (Score: 100/100).

### Feature B: Explainable Risk Score
Every analysis produces:
- A transparent score from 0 to 100.
- A severity category (Lower Detected Risk, Caution, High Risk, Critical Risk).
- A plain-language verdict.
- **Exact observable evidence quotes** matched from the input text.
- Score contribution breakdown (+15, +20, +40, or Critical Override).
- Clear unverified limitations disclosure.

### Feature C: "What Changed?" Fraud Replay Simulator
Interactive side-by-side simulator demonstrating engine sensitivity:
- Compare scam variants (e.g., urgency threat vs official bank notice).
- Real-time delta score calculation.
- **Crucial Cybersecurity Principle:** Educates users that removing threat words does *not* prove authenticity.

### Feature D: Judge-Ready Demo Lab
Dedicated interactive lab preloaded with 7 realistic test vectors:
1. Legitimate Grocery Merchant Payment (Normal flow, score 0/100)
2. Fake Cashback Reward & PIN Trap (Critical override, score 100/100)
3. Fake Account Suspension & Panic Threat (Urgency + deceptive domain, score 68/100)
4. Dangerous Refund Offer via AnyDesk (Remote-access trap, score 40/100)
5. First Payment to an Unknown Recipient (Measured ₹1 caution, score 5/100)
6. Standard Payment Authorization Flow (PIN in authorization context, score 0/100)
7. Prize Bait with Shortened bit.ly URL (Phishing link, score 33/100)

---

## 3. Architecture & Tech Stack

- **Framework:** React 19 + TypeScript + Vite
- **Styling:** Tailwind CSS (Modern token hierarchy, accessible color contrast)
- **Local QR Engine:** Browser Canvas + `jsqr` (100% on-device image decoding)
- **Testing:** Node.js native test runner (`node:test`, `node:assert/strict`)
- **Speech:** Web Speech API text-to-speech for elderly / accessible narration
- **Localization:** Trilingual dictionary in English, Hindi (हिंदी), and Gujarati (ગુજરાતી)

```
src/
├── types/index.ts            # TypeScript data contracts & interfaces
├── engine/
│   ├── rules.ts              # Deduplicated fraud rules, weights, and rationales
│   ├── riskEngine.ts         # Deterministic intent-aware evaluation engine
│   ├── urlAnalyzer.ts        # Safe local URL and domain parser
│   ├── qrAnalyzer.ts         # NPCI UPI deep link & local canvas QR decoder
│   ├── scenarios.ts          # 7 Judge-ready demo test fixtures
│   └── riskEngine.test.ts    # 12 automated test cases
├── i18n/
│   ├── translations.ts       # Trilingual strings (EN, HI, GU)
│   └── LanguageContext.tsx   # React localization provider
├── components/
│   ├── Navbar.tsx            # Header with language switcher & 1930 helpline
│   ├── PrivacyBanner.tsx     # On-device privacy assurance banner
│   ├── Hero.tsx              # Golden Rule banner & primary CTAs
│   ├── AnalyzerWorkspace.tsx # Multi-modal input workspace (Text/URL/QR/VPA)
│   ├── AnalysisResultCard.tsx# Explainable score, evidence, and actions
│   ├── SafetyInterruptModal.tsx# PausePay Safety Interrupt modal
│   ├── ExplainabilityDrawer.tsx# "Why this result?" breakdown drawer
│   ├── WhatChangedSimulator.tsx# Side-by-side comparison simulator
│   ├── DemoLab.tsx           # Judge test vector lab
│   ├── SafetyLearningCenter.tsx# 5-step checklist & 6 core lessons
│   └── Footer.tsx            # Official reporting info (1930 & cybercrime.gov.in)
└── App.tsx                   # Master application orchestrator
```

---

## 4. How to Run Locally

### Prerequisites
Node.js 20+ (Node 22 recommended)

### Installation
```bash
npm install
```

### Run Unit Tests
```bash
npm test
# Or directly:
node --test src/engine/riskEngine.test.ts
```
*Result: 12 passing tests, 0 failures.*

### Start Development Server
```bash
npm run dev
```
Open [http://localhost:3000](http://localhost:3000) in your browser.

### Build for Production
```bash
npm run build
```

---

## 5. Privacy & Security Safeguards

1. **Zero External Data Transmission:** Text, URLs, and QR code image files remain entirely inside client-side browser memory.
2. **No Bank Credentials Collected:** The prototype never requests, accepts, or stores real UPI PINs, OTPs, CVVs, or passwords.
3. **Synthetic Sandbox:** Uses fictional merchants and VPAs; no live financial transactions.
4. **No Network URL Fetching:** PausePay analyzes link syntax and domain heuristics locally without requesting or executing third-party web pages.
5. **Government Reporting Guidance:** Directly highlights the **National Cyber Crime Helpline 1930** and **https://cybercrime.gov.in/**.

---

## 6. Limitations & Future Development

- **Current Prototype:** Runs heuristic and structural rules. Does not connect to live NPCI or bank databases.
- **Future Production Roadmap:**
  1. On-device localized small language models (SLMs) via WebLLM for dialect-specific nuance.
  2. Integration with official NPCI sandbox APIs for verified merchant badge lookup.
  3. Real-time Android accessibility service integration to warn users directly inside payment apps before entering PIN.
