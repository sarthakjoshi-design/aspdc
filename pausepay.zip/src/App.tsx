import React, { useState, useEffect, useRef } from 'react';
import { LanguageProvider } from './i18n/LanguageContext.tsx';
import { Navbar } from './components/Navbar.tsx';
import { PrivacyBanner } from './components/PrivacyBanner.tsx';
import { Hero } from './components/Hero.tsx';
import { AnalyzerWorkspace } from './components/AnalyzerWorkspace.tsx';
import { AnalysisResultCard } from './components/AnalysisResultCard.tsx';
import { SafetyInterruptModal } from './components/SafetyInterruptModal.tsx';
import { ExplainabilityDrawer } from './components/ExplainabilityDrawer.tsx';
import { WhatChangedSimulator } from './components/WhatChangedSimulator.tsx';
import { DemoLab } from './components/DemoLab.tsx';
import { SafetyLearningCenter } from './components/SafetyLearningCenter.tsx';
import { Footer } from './components/Footer.tsx';
import { AnalysisInput, AnalysisResult } from './types/index.ts';
import { evaluateRisk } from './engine/riskEngine.ts';
import { DEMO_SCENARIOS } from './engine/scenarios.ts';

const defaultInput: AnalysisInput = {
  mode: 'message',
  text: '',
  url: '',
  qrPayload: '',
  recipientVpa: '',
  recipientName: '',
  amount: '',
  intent: 'send_money',
  isNewRecipient: false,
};

function MainContent() {
  const [activeTab, setActiveTab] = useState<'analyze' | 'demolab' | 'whatchanged' | 'guide'>('analyze');
  const [currentInput, setCurrentInput] = useState<AnalysisInput>(defaultInput);
  const [analysisResult, setAnalysisResult] = useState<AnalysisResult | null>(null);
  const [showInterruptModal, setShowInterruptModal] = useState<boolean>(false);
  const [showExplainability, setShowExplainability] = useState<boolean>(false);

  const resultsRef = useRef<HTMLDivElement>(null);

  // Handle URL query parameters (e.g. ?scenario=cashback or ?autostart=1)
  useEffect(() => {
    const params = new URLSearchParams(window.location.search);
    const scenarioParam = params.get('scenario');
    if (scenarioParam) {
      const match = DEMO_SCENARIOS.find((s) => s.id.includes(scenarioParam));
      if (match) {
        setCurrentInput(match.input);
        const res = evaluateRisk(match.input);
        setAnalysisResult(res);
        if (res.riskLevel === 'critical' || res.riskLevel === 'high') {
          setShowInterruptModal(true);
        }
      }
    }
  }, []);

  const handleRunAnalysis = (inputToEvaluate: AnalysisInput) => {
    const result = evaluateRisk(inputToEvaluate);
    setAnalysisResult(result);

    // If Critical or High Risk is identified, trigger the PausePay Safety Interrupt
    if (result.riskLevel === 'critical' || result.riskLevel === 'high') {
      setShowInterruptModal(true);
    }

    // Smooth scroll to results
    setTimeout(() => {
      resultsRef.current?.scrollIntoView({ behavior: 'smooth', block: 'start' });
    }, 100);
  };

  const handleReset = () => {
    setCurrentInput(defaultInput);
    setAnalysisResult(null);
    setShowInterruptModal(false);
    setShowExplainability(false);
  };

  const handleLoadFromDemoLab = (scenarioInput: AnalysisInput) => {
    setCurrentInput(scenarioInput);
    setActiveTab('analyze');
    handleRunAnalysis(scenarioInput);
  };

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 flex flex-col font-sans selection:bg-teal-500 selection:text-slate-950">
      {/* Top Navbar */}
      <Navbar activeTab={activeTab} setActiveTab={setActiveTab} />

      {/* Privacy Guarantee Pill */}
      <PrivacyBanner />

      {/* Main Body */}
      <main className="flex-1">
        {/* Hero Section (visible primarily on analyze or general views) */}
        {activeTab === 'analyze' && (
          <Hero
            onAnalyzeClick={() => {
              const el = document.getElementById('analyzer-section');
              el?.scrollIntoView({ behavior: 'smooth' });
            }}
            onDemoClick={() => setActiveTab('demolab')}
            onWhatChangedClick={() => setActiveTab('whatchanged')}
          />
        )}

        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8" id="analyzer-section">
          {/* View 1: Main Analyzer */}
          {activeTab === 'analyze' && (
            <div>
              {/* Input Workspace */}
              <AnalyzerWorkspace
                onAnalyze={handleRunAnalysis}
                onReset={handleReset}
                currentInput={currentInput}
                setCurrentInput={setCurrentInput}
              />

              {/* Results Area */}
              <div ref={resultsRef} className="scroll-mt-24">
                {analysisResult && (
                  <AnalysisResultCard
                    result={analysisResult}
                    onOpenExplainability={() => setShowExplainability(true)}
                    onOpenChecklist={() => setActiveTab('guide')}
                  />
                )}
              </div>
            </div>
          )}

          {/* View 2: Demo Lab */}
          {activeTab === 'demolab' && (
            <DemoLab onLoadIntoAnalyzer={handleLoadFromDemoLab} />
          )}

          {/* View 3: What Changed? Simulator */}
          {activeTab === 'whatchanged' && <WhatChangedSimulator />}

          {/* View 4: Safety Guide & Checklist */}
          {activeTab === 'guide' && <SafetyLearningCenter />}
        </div>
      </main>

      {/* Footer */}
      <Footer />

      {/* Popups & Drawers */}
      {analysisResult && (
        <>
          <SafetyInterruptModal
            result={analysisResult}
            isOpen={showInterruptModal}
            onClose={() => setShowInterruptModal(false)}
          />

          <ExplainabilityDrawer
            result={analysisResult}
            isOpen={showExplainability}
            onClose={() => setShowExplainability(false)}
          />
        </>
      )}
    </div>
  );
}

export default function App() {
  return (
    <LanguageProvider>
      <MainContent />
    </LanguageProvider>
  );
}
