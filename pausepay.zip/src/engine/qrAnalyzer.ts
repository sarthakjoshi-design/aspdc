import jsQR from 'jsqr';
import type { ParsedUpiDetails } from '../types/index.ts';

export function parseUpiPayload(payload: string): ParsedUpiDetails {
  const trimmed = payload.trim();
  const unverifiedFields: string[] = [
    'Payee Name (self-reported in QR; not independently authenticated)',
    'Payee Account Owner (VPA identity cannot be validated without bank integration)',
  ];

  if (!trimmed.toLowerCase().startsWith('upi://pay')) {
    // Might be raw VPA or non-standard payload
    const isPossibleVpa = /^[a-zA-Z0-9.\-_]{2,256}@[a-zA-Z]{2,64}$/.test(trimmed);
    return {
      rawPayload: payload,
      isUpiScheme: isPossibleVpa,
      payeeVpa: isPossibleVpa ? trimmed : undefined,
      unverifiedFields,
    };
  }

  try {
    const url = new URL(trimmed);
    const searchParams = url.searchParams;

    const payeeVpa = searchParams.get('pa') || undefined;
    const payeeName = searchParams.get('pn') || undefined;
    const requestedAmount = searchParams.get('am') || undefined;
    const transactionNote = searchParams.get('tn') || undefined;
    const transactionRef = searchParams.get('tr') || undefined;
    const currency = searchParams.get('cu') || 'INR';

    return {
      rawPayload: payload,
      isUpiScheme: true,
      payeeVpa: payeeVpa ? decodeURIComponent(payeeVpa) : undefined,
      payeeName: payeeName ? decodeURIComponent(payeeName) : undefined,
      requestedAmount: requestedAmount ? decodeURIComponent(requestedAmount) : undefined,
      transactionNote: transactionNote ? decodeURIComponent(transactionNote) : undefined,
      transactionRef: transactionRef ? decodeURIComponent(transactionRef) : undefined,
      currency,
      unverifiedFields,
    };
  } catch {
    // Fallback regex parsing if URL parser fails on customized upi: format
    const paMatch = trimmed.match(/[?&]pa=([^&]+)/i);
    const pnMatch = trimmed.match(/[?&]pn=([^&]+)/i);
    const amMatch = trimmed.match(/[?&]am=([^&]+)/i);
    const tnMatch = trimmed.match(/[?&]tn=([^&]+)/i);

    return {
      rawPayload: payload,
      isUpiScheme: true,
      payeeVpa: paMatch ? decodeURIComponent(paMatch[1]) : undefined,
      payeeName: pnMatch ? decodeURIComponent(pnMatch[1]) : undefined,
      requestedAmount: amMatch ? decodeURIComponent(amMatch[1]) : undefined,
      transactionNote: tnMatch ? decodeURIComponent(tnMatch[1]) : undefined,
      currency: 'INR',
      unverifiedFields,
    };
  }
}

export async function decodeQrFromImageFile(file: File): Promise<string> {
  return new Promise((resolve, reject) => {
    if (!file.type.startsWith('image/')) {
      return reject(new Error('Please upload an image file (PNG, JPG, WEBP).'));
    }

    const reader = new FileReader();
    reader.onerror = () => reject(new Error('Failed to read the image file.'));
    reader.onload = () => {
      const img = new Image();
      img.onerror = () => reject(new Error('Failed to load image for QR decoding.'));
      img.onload = () => {
        try {
          const canvas = document.createElement('canvas');
          const ctx = canvas.getContext('2d');
          if (!ctx) {
            return reject(new Error('Canvas 2D context unavailable in current browser.'));
          }

          canvas.width = img.naturalWidth || img.width;
          canvas.height = img.naturalHeight || img.height;
          ctx.drawImage(img, 0, 0, canvas.width, canvas.height);

          const imageData = ctx.getImageData(0, 0, canvas.width, canvas.height);
          const code = jsQR(imageData.data, imageData.width, imageData.height, {
            inversionAttempts: 'attemptBoth',
          });

          if (code && code.data) {
            resolve(code.data);
          } else {
            reject(
              new Error(
                'No QR code could be detected in this image. Please ensure the QR code is clearly visible, or paste the UPI payload manually below.'
              )
            );
          }
        } catch (err: unknown) {
          const msg = err instanceof Error ? err.message : String(err);
          reject(new Error(`QR decode error: ${msg}`));
        }
      };

      if (typeof reader.result === 'string') {
        img.src = reader.result;
      } else {
        reject(new Error('Could not convert image to data URL.'));
      }
    };

    reader.readAsDataURL(file);
  });
}
