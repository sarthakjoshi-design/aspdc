import type { ParsedUrlDetails } from '../types/index.ts';

const SHORTENER_DOMAINS = new Set([
  'bit.ly',
  'tinyurl.com',
  'is.gd',
  't.co',
  'ow.ly',
  'buff.ly',
  'rb.gy',
  'cutt.ly',
  'shorturl.at',
  'tiny.cc',
  'rebrand.ly',
  'goo.gl',
  'dl.flipkart.com',
]);

const SUSPICIOUS_TLDS = new Set([
  '.xyz',
  '.top',
  '.click',
  '.loan',
  '.work',
  '.vip',
  '.gq',
  '.cf',
  '.tk',
  '.ml',
  '.cc',
  '.rest',
  '.fit',
  '.club',
  '.monster',
]);

const BRAND_DECEPTIVE_PATTERNS = [
  { brand: 'SBI', pattern: /sbi[-_.]?(kyc|reward|bonus|online|portal|update|verify|help)/i },
  { brand: 'HDFC', pattern: /hdfc[-_.]?(kyc|netbanking|login|update|verify|help)/i },
  { brand: 'ICICI', pattern: /icici[-_.]?(kyc|secure|update|login|support)/i },
  { brand: 'Paytm', pattern: /paytm[-_.]?(cash|reward|lottery|bonus|refund|kyc)/i },
  { brand: 'PhonePe', pattern: /phonepe[-_.]?(cash|reward|support|refund|bonus)/i },
  { brand: 'Google Pay', pattern: /(gpay|googlepay)[-_.]?(reward|bonus|cash|offer)/i },
  { brand: 'UPI', pattern: /upi[-_.]?(refund|claim|portal|reward|helpdesk|support)/i },
];

const IP_V4_REGEX = /^(?:(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.){3}(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)$/;

export function extractUrlsFromText(text: string): string[] {
  if (!text) return [];
  const urlRegex = /(https?:\/\/[^\s]+|www\.[^\s]+|[a-zA-Z0-9-]+\.(?:xyz|top|click|loan|work|vip|com|in|org|net|co|ly)\/[^\s]*)/gi;
  const matches = text.match(urlRegex);
  return matches ? Array.from(new Set(matches)) : [];
}

export function analyzeUrl(rawUrl: string): ParsedUrlDetails {
  const warnings: string[] = [];
  let trimmed = rawUrl.trim();
  if (!trimmed.startsWith('http://') && !trimmed.startsWith('https://')) {
    trimmed = 'http://' + trimmed;
  }

  let parsed: URL;
  try {
    parsed = new URL(trimmed);
  } catch {
    return {
      rawUrl,
      isValid: false,
      warnings: ['Invalid or unparseable URL format.'],
    };
  }

  const hostname = parsed.hostname.toLowerCase();
  const isIpAddress = IP_V4_REGEX.test(hostname);
  let isShortener = false;
  let hasLookalikeBrands = false;
  let brandImpersonated: string | undefined;

  // Check valid hostname domain
  if (!isIpAddress && !hostname.includes('.') && !hostname.includes('localhost')) {
    return {
      rawUrl,
      isValid: false,
      warnings: ['Hostname lacks a valid top-level domain structure (TLD).'],
    };
  }

  // Check URL shortener
  for (const domain of SHORTENER_DOMAINS) {
    if (hostname === domain || hostname.endsWith('.' + domain)) {
      isShortener = true;
      warnings.push(`URL uses known link-shortener (${hostname}) which obscures the true destination.`);
      break;
    }
  }

  // Check IP address hostname
  if (isIpAddress) {
    warnings.push(`Destination uses a raw IP address (${hostname}) instead of a verified domain name.`);
  }

  // Check suspicious TLD
  for (const tld of SUSPICIOUS_TLDS) {
    if (hostname.endsWith(tld)) {
      warnings.push(`Uses a high-risk domain extension (${tld}) frequently associated with phishing campaigns.`);
      break;
    }
  }

  // Check deceptive banking brand in hostname
  for (const { brand, pattern } of BRAND_DECEPTIVE_PATTERNS) {
    if (pattern.test(hostname) || pattern.test(parsed.pathname)) {
      hasLookalikeBrands = true;
      brandImpersonated = brand;
      warnings.push(`Domain contains deceptive brand keywords mimicking ${brand}.`);
      break;
    }
  }

  // Check insecure HTTP
  if (parsed.protocol === 'http:' && !hostname.includes('localhost')) {
    warnings.push('Connection is unencrypted (HTTP). Note: even HTTPS does not prove merchant legitimacy.');
  }

  // Query parameter count
  const queryParamsCount = Array.from(parsed.searchParams.keys()).length;

  return {
    rawUrl,
    isValid: true,
    protocol: parsed.protocol.replace(':', ''),
    hostname,
    isIpAddress,
    isShortener,
    hasLookalikeBrands,
    brandImpersonated,
    queryParamsCount,
    warnings,
  };
}
