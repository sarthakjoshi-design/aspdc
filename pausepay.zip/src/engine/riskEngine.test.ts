import test from 'node:test';
import assert from 'node:assert/strict';
import { evaluateRisk } from './riskEngine.ts';
import { analyzeUrl } from './urlAnalyzer.ts';
import { parseUpiPayload } from './qrAnalyzer.ts';

test('Test 1: Ordinary merchant payment produces low risk without fraud alerts', () => {
  const result = evaluateRisk({
    mode: 'message',
    text: 'I am paying ₹450 to my regular local grocery merchant.',
    intent: 'send_money',
  });

  assert.equal(result.riskLevel, 'low');
  assert.equal(result.isCriticalOverride, false);
  assert.ok(result.riskScore < 20, `Expected score < 20, got ${result.riskScore}`);
  assert.ok(!result.indicators.some((i) => i.id === 'PIN_TO_RECEIVE'));
  assert.ok(!result.indicators.some((i) => i.id === 'CREDENTIAL_DISCLOSURE'));
});

test('Test 2: PIN-to-receive scam triggers critical override and clear advice', () => {
  const result = evaluateRisk({
    mode: 'message',
    text: 'You have received a reward. Enter your UPI PIN to receive ₹5,000.',
    intent: 'receive_money',
  });

  assert.equal(result.riskLevel, 'critical');
  assert.equal(result.isCriticalOverride, true);
  assert.ok(result.riskScore >= 95, `Expected score >= 95, got ${result.riskScore}`);
  const pinRule = result.indicators.find((i) => i.id === 'PIN_TO_RECEIVE');
  assert.ok(pinRule, 'PIN_TO_RECEIVE indicator must be present');
  assert.ok(pinRule.evidence.length > 0, 'Evidence must contain matched text');
  assert.match(result.recommendedNextAction.toLowerCase(), /stop/);
});

test('Test 3: Credential disclosure demand triggers critical risk', () => {
  const result = evaluateRisk({
    mode: 'message',
    text: 'Send me your UPI PIN so I can reverse the failed transaction.',
    intent: 'review_request',
  });

  assert.equal(result.riskLevel, 'critical');
  assert.equal(result.isCriticalOverride, true);
  const credRule = result.indicators.find((i) => i.id === 'CREDENTIAL_DISCLOSURE');
  assert.ok(credRule, 'CREDENTIAL_DISCLOSURE indicator must be present');
});

test('Test 4: Urgent bank impersonation detects suspension threat and urgency without fabricating URLs', () => {
  const result = evaluateRisk({
    mode: 'message',
    text: 'Your bank account will be suspended within ten minutes unless you pay a verification fee.',
    intent: 'verify_message',
  });

  assert.ok(result.riskScore >= 35, `Expected score >= 35, got ${result.riskScore}`);
  assert.ok(result.indicators.some((i) => i.id === 'ACCOUNT_BLOCK_THREAT'));
  assert.ok(result.indicators.some((i) => i.id === 'URGENCY_PRESSURE'));
  assert.equal(result.parsedUrl, undefined, 'No URL should be fabricated when none supplied');
});

test('Test 5: Suspicious shortened link and reward bait are correctly flagged', () => {
  const result = evaluateRisk({
    mode: 'link',
    text: 'Claim your limited-time reward using this link: https://bit.ly/cash-reward-500',
    url: 'https://bit.ly/cash-reward-500',
    intent: 'verify_message',
  });

  assert.ok(result.indicators.some((i) => i.id === 'SUSPICIOUS_LINK'));
  assert.ok(result.indicators.some((i) => i.id === 'REWARD_LOTTERY_BAIT'));
  assert.ok(result.parsedUrl?.isShortener, 'Should detect bit.ly as a shortener');
});

test('Test 6: Unknown recipient alone produces modest verification warning, not fraud accusation', () => {
  const result = evaluateRisk({
    mode: 'message',
    text: 'I need to pay ₹100 to a new recipient.',
    intent: 'send_money',
    isNewRecipient: true,
  });

  assert.notEqual(result.riskLevel, 'critical', 'Unknown recipient alone must not trigger critical risk');
  assert.ok(result.riskScore <= 20, `Expected low/caution score, got ${result.riskScore}`);
  assert.ok(result.indicators.some((i) => i.id === 'NEW_UNVERIFIED_RECIPIENT'));
});

test('Test 7: Normal payment authorization mentioning PIN does NOT trigger PIN-to-receive override', () => {
  const result = evaluateRisk({
    mode: 'message',
    text: 'My payment application may ask for my UPI PIN to authorize a transfer.',
    intent: 'send_money',
  });

  assert.equal(result.isCriticalOverride, false);
  assert.notEqual(result.riskLevel, 'critical');
  assert.ok(!result.indicators.some((i) => i.id === 'PIN_TO_RECEIVE'));
  assert.ok(!result.indicators.some((i) => i.id === 'CREDENTIAL_DISCLOSURE'));
});

test('Test 8: Remote-access software paired with banking triggers strong warning', () => {
  const result = evaluateRisk({
    mode: 'message',
    text: 'A stranger says I must install AnyDesk and share my screen while opening my payment app.',
    intent: 'review_request',
  });

  assert.ok(result.indicators.some((i) => i.id === 'REMOTE_ACCESS_SOFTWARE'));
  assert.ok(result.riskScore >= 40, `Expected elevated score >= 40, got ${result.riskScore}`);
});

test('Test 9: Malformed link handles cleanly without crashing', () => {
  const parsed = analyzeUrl('not-a-valid-url:::///bad');
  assert.equal(parsed.isValid, false);
  assert.ok(parsed.warnings.length > 0);

  const result = evaluateRisk({
    mode: 'link',
    url: 'invalid---url',
    intent: 'verify_message',
  });
  assert.ok(result.riskScore >= 0);
  assert.ok(result.indicators.some((i) => i.id === 'MALFORMED_URL'));
});

test('Test 10: Legitimate-looking UPI QR payload extracts payee and amount with honesty limitations', () => {
  const payload = 'upi://pay?pa=merchant@okhdfcbank&pn=SuperStore&am=450.00&cu=INR&tn=Groceries';
  const parsed = parseUpiPayload(payload);

  assert.equal(parsed.isUpiScheme, true);
  assert.equal(parsed.payeeVpa, 'merchant@okhdfcbank');
  assert.equal(parsed.payeeName, 'SuperStore');
  assert.equal(parsed.requestedAmount, '450.00');
  assert.equal(parsed.transactionNote, 'Groceries');
  assert.ok(parsed.unverifiedFields.length > 0, 'Must document unverified identity limitations');
});

test('Test 11: Empty input handles cleanly without throwing or fabricating scores', () => {
  const result = evaluateRisk({
    mode: 'message',
    text: '',
    intent: 'send_money',
  });

  assert.equal(result.riskScore, 0);
  assert.equal(result.riskLevel, 'low');
  assert.equal(result.indicators.length, 0);
});

test('Test 12: Deduplication and score bounds strictly adhere to 0-100 range', () => {
  // Input with repeated urgency words
  const result = evaluateRisk({
    mode: 'message',
    text: 'Urgent urgent urgent immediately immediately! Act fast in 5 minutes! Claim prize prize lottery win ₹10,000!',
    intent: 'understand_instruction',
  });

  // Urgency indicator should only appear once
  const urgencyCount = result.indicators.filter((i) => i.id === 'URGENCY_PRESSURE').length;
  assert.equal(urgencyCount, 1, 'Urgency indicator must be deduplicated');

  // Score must remain <= 100
  assert.ok(result.riskScore >= 0 && result.riskScore <= 100, `Score must be between 0 and 100, got ${result.riskScore}`);
});
