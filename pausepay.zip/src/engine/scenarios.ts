import type { DemoScenario } from '../types/index.ts';

export const DEMO_SCENARIOS: DemoScenario[] = [
  {
    id: 'scenario_normal_grocery',
    title: 'Grocery Store Payment',
    type: 'Legitimate Merchant',
    intent: 'send_money',
    description: 'An everyday merchant transaction at a local grocery store.',
    input: {
      mode: 'message',
      text: 'I am paying ₹450 for groceries to my usual store.',
      amount: '450',
      recipientName: 'Shree Krishna Provisions',
      recipientVpa: 'krishnagrocery@okhdfcbank',
      intent: 'send_money',
      isNewRecipient: false,
    },
    keyLearning:
      'Ordinary merchant payments trigger no false alerts. PausePay provides a peaceful verification checklist to confirm the amount and payee before paying.',
  },
  {
    id: 'scenario_pin_receive_cashback',
    title: 'Fake Cashback Reward & PIN Trap',
    type: 'Critical PIN Scam',
    intent: 'receive_money',
    description: 'A classic reward lure urging the victim to enter their UPI PIN to receive money.',
    input: {
      mode: 'message',
      text: 'Congratulations! You have won ₹5,000 cashback. Scan this code and enter your UPI PIN to receive the reward within five minutes.',
      qrPayload: 'upi://pay?pa=cashback_claims@okhdfcbank&pn=MegaRewards&am=5000&cu=INR&tn=Cashback%20Reward',
      intent: 'receive_money',
    },
    keyLearning:
      'Triggers the critical PIN-to-receive override! Educates the user that receiving money NEVER requires entering a UPI PIN.',
  },
  {
    id: 'scenario_bank_impersonation',
    title: 'Fake Account Suspension & Panic Threat',
    type: 'Impersonation & Threat',
    intent: 'verify_message',
    description: 'High-pressure panic SMS threatening immediate account block unless a fee is paid.',
    input: {
      mode: 'message',
      text: 'ALERT: Your bank account will be blocked in 10 minutes. Pay the verification fee through this link immediately: http://sbi-kyc-verify.top/pay',
      url: 'http://sbi-kyc-verify.top/pay',
      intent: 'verify_message',
    },
    keyLearning:
      'Detects multiple correlated signals: urgent deadline (10 mins), account suspension threat, advance fee trap, and lookalike deceptive banking domain on .top TLD.',
  },
  {
    id: 'scenario_remote_access_refund',
    title: 'Dangerous Refund Offer via Screen Share',
    type: 'Remote-Access Software Trap',
    intent: 'review_request',
    description: 'Fraudster posing as support requests installation of screen sharing software to process refund.',
    input: {
      mode: 'message',
      text: 'Your refund of ₹1,800 is pending. Install the AnyDesk support application, share your screen, and enter your banking details so our agent can release it.',
      intent: 'review_request',
    },
    keyLearning:
      'Identifies the extreme danger of remote-access tools (AnyDesk/TeamViewer) during banking activity. Scammers use this to snoop credentials and OTPs.',
  },
  {
    id: 'scenario_new_merchant_payment',
    title: 'First Payment to a New Merchant',
    type: 'Unfamiliar Recipient',
    intent: 'send_money',
    description: 'Paying a newly encountered person or seller for the first time.',
    input: {
      mode: 'message',
      text: 'I want to pay ₹250 to a merchant I have not used before.',
      recipientVpa: 'newvendor99@okaxis',
      amount: '250',
      intent: 'send_money',
      isNewRecipient: true,
    },
    keyLearning:
      'Does NOT accuse the recipient of fraud. Provides measured, proportionate caution: recommends doing a ₹1 test transaction before transferring the full amount.',
  },
  {
    id: 'scenario_legit_pin_authorization',
    title: 'Standard Payment Authorization Flow',
    type: 'Legitimate PIN Context',
    intent: 'send_money',
    description: 'A normal checkout flow where PIN is correctly mentioned for payment authorization.',
    input: {
      mode: 'message',
      text: 'I am using my payment app to pay a merchant and will authorize the payment in the app using my UPI PIN.',
      intent: 'send_money',
      isNewRecipient: false,
    },
    keyLearning:
      'Smart semantic context recognition: entering a PIN to authorize an outgoing transfer is normal. Avoids false alarms while reminding user to verify the recipient.',
  },
  {
    id: 'scenario_lottery_short_link',
    title: 'Prize Bait with Shortened URL',
    type: 'Phishing Link Bait',
    intent: 'verify_message',
    description: 'Festive prize claim message containing an obscured bit.ly shortlink.',
    input: {
      mode: 'link',
      text: 'Claim your limited-time festive reward of ₹2,500 using this link: https://bit.ly/claim-festive-cash',
      url: 'https://bit.ly/claim-festive-cash',
      intent: 'verify_message',
    },
    keyLearning:
      'Flags reward bait and masked URL shortener. Crucially avoids false critical PIN overrides because no PIN instruction was present in the input.',
  },
];
