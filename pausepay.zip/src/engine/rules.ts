export interface RuleDefinition {
  id: string;
  name: string;
  category: 'credential_security' | 'urgency_coercion' | 'reward_financial_bait' | 'remote_access' | 'link_safety' | 'recipient_verification' | 'impersonation';
  severity: 'critical' | 'high' | 'medium' | 'low';
  weight: number;
  isCriticalOverride?: boolean;
  whyItMatters: string;
  actionAdvice: string;
}

export const RISK_RULES: Record<string, RuleDefinition> = {
  PIN_TO_RECEIVE: {
    id: 'PIN_TO_RECEIVE',
    name: 'PIN-to-Receive Money Trap',
    category: 'credential_security',
    severity: 'critical',
    weight: 95,
    isCriticalOverride: true,
    whyItMatters:
      'A UPI PIN is used exclusively to DEBIT funds from your account. You NEVER need to enter a UPI PIN, scan a QR code, or approve a collect request to receive or credit money into your account.',
    actionAdvice:
      'STOP immediately. Do not enter your UPI PIN. Refuse any payment or collect request that claims it will deposit money.',
  },
  CREDENTIAL_DISCLOSURE: {
    id: 'CREDENTIAL_DISCLOSURE',
    name: 'Credential Disclosure Demand',
    category: 'credential_security',
    severity: 'critical',
    weight: 95,
    isCriticalOverride: true,
    whyItMatters:
      'No legitimate bank, merchant, or payment support agent will ever ask you to tell, share, or message your UPI PIN, OTP, CVV, or net banking password.',
    actionAdvice:
      'Never disclose your UPI PIN or OTP to anyone, even if they claim to be customer support, police, or bank officials.',
  },
  REMOTE_ACCESS_SOFTWARE: {
    id: 'REMOTE_ACCESS_SOFTWARE',
    name: 'Unsolicited Remote-Access / Screen-Sharing Request',
    category: 'remote_access',
    severity: 'high',
    weight: 40,
    whyItMatters:
      'Scammers instruct victims to install remote desktop tools (like AnyDesk, TeamViewer, or QuickSupport) to view their screen, harvest OTPs, or gain control while banking apps are open.',
    actionAdvice:
      'Do not install remote-access software or share your screen during payment or banking activities under any circumstances.',
  },
  ACCOUNT_BLOCK_THREAT: {
    id: 'ACCOUNT_BLOCK_THREAT',
    name: 'Coercive Account Suspension / KYC Threat',
    category: 'urgency_coercion',
    severity: 'high',
    weight: 20,
    whyItMatters:
      'Threatening that your bank account, electricity, SIM card, or PAN/KYC will be blocked in minutes is a classic panic tactic designed to rush you into paying without thinking.',
    actionAdvice:
      'Do not use any link or number in the message. Verify your account status by opening your official bank application independently.',
  },
  URGENCY_PRESSURE: {
    id: 'URGENCY_PRESSURE',
    name: 'Artificial Urgency / Pressure Tactic',
    category: 'urgency_coercion',
    severity: 'medium',
    weight: 15,
    whyItMatters:
      'Imposing strict time limits (e.g., "within 5 minutes", "act immediately") forces emotional compliance and bypasses your normal verification caution.',
    actionAdvice:
      'Pause and take a breath. Genuine financial matters rarely require unverified action within minutes.',
  },
  REWARD_LOTTERY_BAIT: {
    id: 'REWARD_LOTTERY_BAIT',
    name: 'Unsolicited Reward / Cashback Bait',
    category: 'reward_financial_bait',
    severity: 'medium',
    weight: 15,
    whyItMatters:
      'Promises of surprise cashback, lottery prizes, or gift cards are frequently used to lure people into scanning collect QR codes or sharing PINs.',
    actionAdvice:
      'Be skeptical of unsolicited winnings. In UPI, legitimate cashback is credited directly to your bank account without scanning or PIN entry.',
  },
  SUSPICIOUS_LINK: {
    id: 'SUSPICIOUS_LINK',
    name: 'Suspicious or Shortened Link',
    category: 'link_safety',
    severity: 'medium',
    weight: 18,
    whyItMatters:
      'Shortened URLs (like bit.ly) or deceptive domains hide the true destination and frequently redirect to phishing or fake UPI payment gateway portals.',
    actionAdvice:
      'Do not tap or paste links from unknown sources. Always navigate manually via official apps or bookmarks.',
  },
  UNTRUSTED_APP_INSTALL: {
    id: 'UNTRUSTED_APP_INSTALL',
    name: 'Untrusted App / APK Installation Request',
    category: 'remote_access',
    severity: 'high',
    weight: 25,
    whyItMatters:
      'Asking users to download an APK file or install unverified third-party software for "verification" or "refund assistance" is a common malware vector.',
    actionAdvice:
      'Never download APK files or side-load apps sent via SMS, WhatsApp, or email.',
  },
  ADVANCE_FEE_OR_REFUND_TRAP: {
    id: 'ADVANCE_FEE_OR_REFUND_TRAP',
    name: 'Advance Fee or Refund Release Charge',
    category: 'reward_financial_bait',
    severity: 'medium',
    weight: 15,
    whyItMatters:
      'Demanding a small "processing fee", "registration deposit", or "tax clearance" before releasing a larger refund or prize is a hallmark of advance-fee fraud.',
    actionAdvice:
      'Never pay money to receive money. Legitimate refunds are credited automatically without advance payments.',
  },
  NEW_UNVERIFIED_RECIPIENT: {
    id: 'NEW_UNVERIFIED_RECIPIENT',
    name: 'First-Time / Unfamiliar Recipient',
    category: 'recipient_verification',
    severity: 'low',
    weight: 5,
    whyItMatters:
      'Sending money to a newly introduced UPI ID or phone number carries a higher risk of mistyping or fraudulent intent than paying a known merchant.',
    actionAdvice:
      'Perform a ₹1 micro-transaction first to confirm the recipient before transferring the full amount.',
  },
  QR_COLLECT_INTENT_MISMATCH: {
    id: 'QR_COLLECT_INTENT_MISMATCH',
    name: 'Payment Direction Mismatch (Paying instead of Receiving)',
    category: 'credential_security',
    severity: 'high',
    weight: 25,
    whyItMatters:
      'The QR code or payload requests an OUTGOING payment from your account, but your intended action is to RECEIVE money.',
    actionAdvice:
      'Do not scan or approve this QR code. Scanning a QR code always sends money out of your bank account.',
  },
};
