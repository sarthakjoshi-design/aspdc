import type {
  AnalysisInput,
  AnalysisResult,
  RiskIndicator,
  RiskLevel,
  UserIntent,
} from '../types/index.ts';
import { RISK_RULES } from './rules.ts';
import type { RuleDefinition } from './rules.ts';
import { analyzeUrl, extractUrlsFromText } from './urlAnalyzer.ts';
import { parseUpiPayload } from './qrAnalyzer.ts';

// Helper to find exact matching snippet or return fallback evidence
function findSnippet(fullText: string, regex: RegExp, defaultSnippet: string): string {
  const match = fullText.match(regex);
  if (match && match[0]) {
    return match[0].trim();
  }
  return defaultSnippet;
}

export function evaluateRisk(input: AnalysisInput): AnalysisResult {
  const indicators: RiskIndicator[] = [];
  const unverifiedLimitations: string[] = [
    'PausePay runs 100% locally and cannot query live banking networks or confirm sender identity.',
    'A low detected risk does NOT guarantee that the recipient or transaction is safe.',
    'Bank account names, VPA handles, and phone numbers cannot be independently verified by this prototype.',
  ];

  const fullText = (input.text || '') + ' ' + (input.url || '') + ' ' + (input.qrPayload || '');
  const lower = fullText.toLowerCase();
  const intent = input.intent || 'understand_instruction';

  // 1. Check for Legitimate PIN Context (Case C) vs PIN Scams (Case A & B)
  const hasAuthorizePinContext =
    /(authorize|confirm|authenticate|process|complete)\s+(?:the\s+)?(?:transaction|payment|transfer)/i.test(lower) ||
    /app\s+(?:may\s+)?(?:request|ask\s+for)\s+(?:my\s+)?(?:upi\s+)?pin/i.test(lower) ||
    /enter\s+(?:my\s+)?(?:upi\s+)?pin\s+to\s+(?:authorize|confirm|pay|send)/i.test(lower) ||
    /authoriz(?:e|ing)\s+a\s+payment/i.test(lower);

  const isPayingMerchantOrFriend =
    intent === 'send_money' ||
    /(paying|pay\s+for|transferring\s+to)\s+(?:a\s+)?(?:merchant|groceries|store|friend|shop|local)/i.test(lower);

  // Case A: PIN-to-receive scam
  // "Enter your UPI PIN to receive ₹5,000" or receiving intent with PIN entry instruction
  const pinToReceiveRegex =
    /(?:enter|type|input|put|submit|dial)\s+(?:your\s+)?(?:upi\s+)?pin\s+(?:to|for)\s+(?:receive|get|claim|collect|credit|deposit|accept|win)/i;
  const pinForRewardRegex =
    /(?:upi\s+)?pin.*(?:to|for)\s+(?:receive|claim|get)\s+(?:reward|cashback|refund|money|amount|prize)/i;
  const receiveIntentWithPin =
    (intent === 'receive_money' || /to\s+receive\s+(?:₹|rs|\d+)/i.test(lower)) &&
    /(?:enter|type|submit|provide)\s+(?:your\s+)?(?:upi\s+)?pin/i.test(lower);

  if (
    (pinToReceiveRegex.test(lower) || pinForRewardRegex.test(lower) || receiveIntentWithPin) &&
    !hasAuthorizePinContext
  ) {
    const evidence = findSnippet(
      fullText,
      /(?:enter|type|input|put|submit)\s+(?:your\s+)?(?:upi\s+)?pin[^\n.!?]*(?:receive|get|claim|collect|credit|deposit|reward|cashback)[^\n.!?]*/i,
      'Instruction to enter UPI PIN to receive or claim money'
    );
    const rule = RISK_RULES.PIN_TO_RECEIVE;
    indicators.push({
      id: rule.id,
      name: rule.name,
      category: rule.category,
      severity: rule.severity,
      scoreContribution: rule.weight,
      evidence,
      whyItMatters: rule.whyItMatters,
      actionAdvice: rule.actionAdvice,
    });
  }

  // Case B: Credential disclosure demand
  // "Tell me your UPI PIN", "share your OTP/PIN so I can refund"
  const isAdvisoryNotToShare =
    /(?:never|do\s+not|don't|not\s+to|refrain\s+from)\s+(?:share|tell|disclose|give|send)\s+(?:your\s+)?(?:upi\s+)?(?:pin|otp|password|cvv)/i.test(lower);

  const sharePinRegex =
    /(?:share|tell|send|give|disclose|message|forward|provide)\s+(?:me\s+)?(?:your\s+)?(?:upi\s+)?(?:pin|otp|password|cvv|secret)/i;
  const askingForPin = /(?:what\s+is\s+your|need\s+your)\s+(?:upi\s+)?(?:pin|otp)/i.test(lower);

  if ((sharePinRegex.test(lower) || askingForPin) && !hasAuthorizePinContext && !isAdvisoryNotToShare) {
    const evidence = findSnippet(
      fullText,
      /(?:share|tell|send|give|disclose|message|forward|provide)\s+(?:me\s+)?(?:your\s+)?(?:upi\s+)?(?:pin|otp|password|cvv)[^\n.!?]*/i,
      'Request to disclose or send UPI PIN / OTP'
    );
    const rule = RISK_RULES.CREDENTIAL_DISCLOSURE;
    indicators.push({
      id: rule.id,
      name: rule.name,
      category: rule.category,
      severity: rule.severity,
      scoreContribution: rule.weight,
      evidence,
      whyItMatters: rule.whyItMatters,
      actionAdvice: rule.actionAdvice,
    });
  }

  // 2. Remote Access / Screen-Sharing Request (+40)
  const remoteAppRegex =
    /(anydesk|teamviewer|rustdesk|quicksupport|ultraviewer|zoho\s+assist|screen\s+share|share\s+(?:your\s+)?screen|remote\s+access)/i;
  const bankingContextRegex =
    /(banking|payment|upi|refund|bank|account|phonepe|gpay|paytm|wallet|card)/i;

  if (remoteAppRegex.test(lower)) {
    const hasBanking = bankingContextRegex.test(lower) || intent !== 'understand_instruction';
    const evidence = findSnippet(
      fullText,
      /[^\n.!?]*(?:anydesk|teamviewer|rustdesk|quicksupport|screen\s+share|share\s+(?:your\s+)?screen|remote\s+access)[^\n.!?]*/i,
      'Request to install remote-access software or share screen'
    );
    const rule = RISK_RULES.REMOTE_ACCESS_SOFTWARE;
    indicators.push({
      id: rule.id,
      name: rule.name,
      category: rule.category,
      severity: rule.severity,
      scoreContribution: hasBanking ? rule.weight : 25,
      evidence,
      whyItMatters: rule.whyItMatters,
      actionAdvice: rule.actionAdvice,
    });
  }

  // 3. Account Block / Suspension Threat (+20)
  const threatRegex =
    /(?:account|sim|card|connection|electricity|pan|kyc)\s+(?:will\s+be\s+|is\s+)?(?:blocked|suspended|frozen|deactivated|disconnected|terminated|closed)/i;
  const urgentThreat =
    /(?:blocked|suspended|deactivated)\s+in\s+\d+\s+(?:minutes|mins|hours)/i.test(lower) ||
    /pay\s+(?:the\s+)?(?:verification\s+fee|due|penalty)\s+immediately/i.test(lower);

  if (threatRegex.test(lower) || urgentThreat) {
    const evidence = findSnippet(
      fullText,
      /[^\n.!?]*(?:blocked|suspended|frozen|deactivated|disconnected|verification\s+fee)[^\n.!?]*/i,
      'Threat of account suspension or service blockage'
    );
    const rule = RISK_RULES.ACCOUNT_BLOCK_THREAT;
    indicators.push({
      id: rule.id,
      name: rule.name,
      category: rule.category,
      severity: rule.severity,
      scoreContribution: rule.weight,
      evidence,
      whyItMatters: rule.whyItMatters,
      actionAdvice: rule.actionAdvice,
    });
  }

  // 4. Urgency & Coercive Pressure (+15)
  const urgencyRegex =
    /(?:(?:in|within)\s+(?:\d+|one|two|three|five|ten|fifteen|twenty|thirty)\s+(?:minutes|mins|hours)|immediately|hurry|act\s+fast|urgent|limited\s+time|before\s+it\s+expires|valid\s+only\s+today|pay\s+immediately)/i;
  if (urgencyRegex.test(lower)) {
    const evidence = findSnippet(
      fullText,
      /[^\n.!?]*(?:(?:in|within)\s+(?:\d+|one|two|three|five|ten|fifteen)\s+(?:minutes|mins|hours)|immediately|hurry|act\s+fast|urgent)[^\n.!?]*/i,
      'High-pressure artificial deadline'
    );
    const rule = RISK_RULES.URGENCY_PRESSURE;
    indicators.push({
      id: rule.id,
      name: rule.name,
      category: rule.category,
      severity: rule.severity,
      scoreContribution: rule.weight,
      evidence,
      whyItMatters: rule.whyItMatters,
      actionAdvice: rule.actionAdvice,
    });
  }

  // 5. Reward / Lottery / Cashback Bait (+15)
  const rewardRegex =
    /(?:congratulations|you\s+have\s+won|won\s+(?:₹|rs\.?|\$)?\s*\d+|cashback\s+of\s+(?:₹|rs\.?|\$)?\s*\d+|lottery\s+winner|prize\s+money|lucky\s+draw|(?:claim|get)\s+(?:your\s+)?(?:[a-z0-9-]+\s+)*(?:reward|prize|cashback|gift))/i;
  if (rewardRegex.test(lower)) {
    const evidence = findSnippet(
      fullText,
      /[^\n.!?]*(?:congratulations|you\s+have\s+won|cashback|lottery|prize|reward|gift)[^\n.!?]*/i,
      'Unsolicited reward or prize announcement'
    );
    const rule = RISK_RULES.REWARD_LOTTERY_BAIT;
    indicators.push({
      id: rule.id,
      name: rule.name,
      category: rule.category,
      severity: rule.severity,
      scoreContribution: rule.weight,
      evidence,
      whyItMatters: rule.whyItMatters,
      actionAdvice: rule.actionAdvice,
    });
  }

  // 6. Untrusted App / APK Download Request (+25)
  const apkRegex =
    /(?:install|download)\s+(?:this\s+)?(?:support|verification|helper|banking)?\s*(?:app|apk|application|tool|software)\b/i;
  if (apkRegex.test(lower) && !indicators.some((i) => i.id === 'REMOTE_ACCESS_SOFTWARE')) {
    const evidence = findSnippet(
      fullText,
      /[^\n.!?]*(?:install|download)\s+(?:this\s+)?(?:support|verification)?\s*(?:app|apk|tool)[^\n.!?]*/i,
      'Request to install unverified software'
    );
    const rule = RISK_RULES.UNTRUSTED_APP_INSTALL;
    indicators.push({
      id: rule.id,
      name: rule.name,
      category: rule.category,
      severity: rule.severity,
      scoreContribution: rule.weight,
      evidence,
      whyItMatters: rule.whyItMatters,
      actionAdvice: rule.actionAdvice,
    });
  }

  // 7. Advance Fee or Refund Release Charge (+15)
  const feeRegex =
    /(?:verification\s+fee|processing\s+fee|registration\s+(?:fee|charge)|advance\s+(?:payment|deposit)|pay\s+(?:₹|rs\.?|\$)?\s*\d+\s+to\s+(?:release|activate|process|receive))/i;
  if (feeRegex.test(lower)) {
    const evidence = findSnippet(
      fullText,
      /[^\n.!?]*(?:verification\s+fee|processing\s+fee|advance\s+fee|pay\s+.*to\s+release)[^\n.!?]*/i,
      'Fee required to receive a refund or payout'
    );
    const rule = RISK_RULES.ADVANCE_FEE_OR_REFUND_TRAP;
    indicators.push({
      id: rule.id,
      name: rule.name,
      category: rule.category,
      severity: rule.severity,
      scoreContribution: rule.weight,
      evidence,
      whyItMatters: rule.whyItMatters,
      actionAdvice: rule.actionAdvice,
    });
  }

  // 8. Link & URL Analysis (+18)
  let parsedUrlResult = undefined;
  const urlsFound = extractUrlsFromText(fullText);
  if (input.url) {
    urlsFound.push(input.url);
  }

  if (urlsFound.length > 0) {
    const targetUrl = urlsFound[0];
    const analyzed = analyzeUrl(targetUrl);
    parsedUrlResult = analyzed;

    if (!analyzed.isValid) {
      indicators.push({
        id: 'MALFORMED_URL',
        name: 'Malformed or Invalid URL',
        category: 'link_safety',
        severity: 'medium',
        scoreContribution: 10,
        evidence: targetUrl,
        whyItMatters: 'The provided link is structurally invalid or corrupted.',
        actionAdvice: 'Do not click or open unformatted or broken links.',
      });
    } else if (analyzed.isShortener || analyzed.isIpAddress || analyzed.hasLookalikeBrands || analyzed.warnings.length > 1) {
      const rule = RISK_RULES.SUSPICIOUS_LINK;
      indicators.push({
        id: rule.id,
        name: rule.name,
        category: rule.category,
        severity: rule.severity,
        scoreContribution: rule.weight,
        evidence: `${analyzed.rawUrl} (${analyzed.warnings.join(' ')})`,
        whyItMatters: rule.whyItMatters,
        actionAdvice: rule.actionAdvice,
      });
    }
  }

  // 9. QR Code & Intent Mismatch (+25)
  let parsedUpiResult = undefined;
  if (input.qrPayload) {
    parsedUpiResult = parseUpiPayload(input.qrPayload);
    // If user's intent is to RECEIVE money, but the QR payload is an outgoing payment link (upi://pay)
    if (intent === 'receive_money' && parsedUpiResult.isUpiScheme) {
      const rule = RISK_RULES.QR_COLLECT_INTENT_MISMATCH;
      indicators.push({
        id: rule.id,
        name: rule.name,
        category: rule.category,
        severity: rule.severity,
        scoreContribution: rule.weight,
        evidence: `QR intent: Send payment (upi://pay to ${parsedUpiResult.payeeVpa || 'merchant'}), but user intended to RECEIVE money.`,
        whyItMatters: rule.whyItMatters,
        actionAdvice: rule.actionAdvice,
      });
    }
  }

  // 10. New or Unfamiliar Recipient (+5) (Case D)
  const isNewRecipientMentioned =
    input.isNewRecipient === true ||
    /(?:new\s+recipient|recipient\s+i\s+have\s+not\s+paid\s+before|unknown\s+recipient|not\s+used\s+before|first\s+time\s+paying|paying\s+someone\s+new)/i.test(lower);

  if (isNewRecipientMentioned && (intent === 'send_money' || isPayingMerchantOrFriend)) {
    const rule = RISK_RULES.NEW_UNVERIFIED_RECIPIENT;
    // Only add if not already saturated with higher indicators
    indicators.push({
      id: rule.id,
      name: rule.name,
      category: rule.category,
      severity: rule.severity,
      scoreContribution: rule.weight,
      evidence: input.recipientVpa
        ? `Recipient VPA: ${input.recipientVpa} (unverified first-time recipient)`
        : 'Payment directed to an unfamiliar or first-time recipient',
      whyItMatters: rule.whyItMatters,
      actionAdvice: rule.actionAdvice,
    });
  }

  // 11. Deduplication by Indicator ID
  const uniqueIndicatorsMap = new Map<string, RiskIndicator>();
  for (const ind of indicators) {
    if (!uniqueIndicatorsMap.has(ind.id)) {
      uniqueIndicatorsMap.set(ind.id, ind);
    }
  }
  const uniqueIndicators = Array.from(uniqueIndicatorsMap.values());

  // 12. Check for Critical Overrides
  const criticalOverrideIndicator = uniqueIndicators.find(
    (ind) => ind.id === 'PIN_TO_RECEIVE' || ind.id === 'CREDENTIAL_DISCLOSURE'
  );
  const isCriticalOverride = Boolean(criticalOverrideIndicator);

  // 13. Calculate Arithmetic Score
  let calculatedScore = 0;
  for (const ind of uniqueIndicators) {
    calculatedScore += ind.scoreContribution;
  }
  calculatedScore = Math.min(100, calculatedScore);

  if (isCriticalOverride) {
    calculatedScore = Math.max(95, calculatedScore);
  }

  // 14. Determine Risk Level
  let riskLevel: RiskLevel = 'low';
  if (calculatedScore >= 70 || isCriticalOverride) {
    riskLevel = 'critical';
  } else if (calculatedScore >= 40) {
    riskLevel = 'high';
  } else if (calculatedScore >= 20) {
    riskLevel = 'caution';
  } else {
    riskLevel = 'low';
  }

  // 15. Sort indicators by severity & score contribution
  const severityRank: Record<string, number> = { critical: 4, high: 3, medium: 2, low: 1 };
  uniqueIndicators.sort((a, b) => {
    const diff = severityRank[b.severity] - severityRank[a.severity];
    if (diff !== 0) return diff;
    return b.scoreContribution - a.scoreContribution;
  });

  const strongestIndicator = uniqueIndicators[0];

  // 16. Contextual Verdict and Recommendations
  let headlineVerdict = '';
  let summaryAdvice = '';
  let recommendedNextAction = '';

  if (riskLevel === 'critical') {
    if (criticalOverrideIndicator?.id === 'PIN_TO_RECEIVE') {
      headlineVerdict = 'CRITICAL FRAUD TRAP: Never Enter UPI PIN to Receive Money';
      summaryAdvice =
        'This request instructs you to enter your UPI PIN or approve a payment in order to receive money or rewards. In UPI, entering a PIN ALWAYS DEBITS money from your bank account.';
      recommendedNextAction = 'STOP immediately. Refuse the request and do not enter your UPI PIN.';
    } else if (criticalOverrideIndicator?.id === 'CREDENTIAL_DISCLOSURE') {
      headlineVerdict = 'CRITICAL SECURITY VIOLATION: Never Share Your UPI PIN or OTP';
      summaryAdvice =
        'A request was made to disclose or share your secret UPI PIN, OTP, or passwords. Legitimate banks and support teams NEVER ask for these credentials.';
      recommendedNextAction = 'Do NOT disclose or message your PIN or OTP. Block and report this sender.';
    } else {
      headlineVerdict = 'CRITICAL RISK DETECTED: High Probability of Digital Financial Fraud';
      summaryAdvice =
        'Multiple severe warning indicators were detected, including coercive threats, remote access requests, or payment direction traps.';
      recommendedNextAction = 'Do not proceed with this transaction. Seek independent verification through verified channels.';
    }
  } else if (riskLevel === 'high') {
    headlineVerdict = 'HIGH RISK: Severe Warning Indicators Identified';
    summaryAdvice =
      'This situation contains significant warning signs, such as remote-access requests, account suspension threats, or deceptive links.';
    recommendedNextAction = 'Pause immediately. Do not install any software or click unverified links.';
  } else if (riskLevel === 'caution') {
    headlineVerdict = 'CAUTION: Warning Indicators Detected — Verify Before Proceeding';
    summaryAdvice =
      'Some suspicious characteristics were found (such as urgency tactics, reward claims, or unfamiliar recipients). Independent verification is recommended.';
    recommendedNextAction = 'Confirm the recipient and amount independently through official contact details before paying.';
  } else {
    // Low risk
    headlineVerdict = 'LOWER DETECTED RISK: Standard Payment Verification Advised';
    summaryAdvice =
      'No obvious scam patterns or critical credential traps were detected in the provided input. However, this tool cannot guarantee the honesty of the recipient.';
    recommendedNextAction = 'Check the payee name and amount on your payment app before entering your UPI PIN.';
  }

  return {
    riskScore: calculatedScore,
    riskLevel,
    isCriticalOverride,
    headlineVerdict,
    summaryAdvice,
    strongestIndicator,
    indicators: uniqueIndicators,
    unverifiedLimitations,
    recommendedNextAction,
    intentContext: intent,
    timestamp: Date.now(),
    parsedUpi: parsedUpiResult,
    parsedUrl: parsedUrlResult,
  };
}
