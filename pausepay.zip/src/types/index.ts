export type UserIntent =
  | 'send_money'
  | 'receive_money'
  | 'scan_qr'
  | 'review_request'
  | 'verify_message'
  | 'understand_instruction';

export type RiskLevel = 'low' | 'caution' | 'high' | 'critical';

export type IndicatorSeverity = 'critical' | 'high' | 'medium' | 'low';

export interface RiskIndicator {
  id: string;
  name: string;
  category: 'credential_security' | 'urgency_coercion' | 'reward_financial_bait' | 'remote_access' | 'link_safety' | 'recipient_verification' | 'impersonation';
  severity: IndicatorSeverity;
  scoreContribution: number;
  evidence: string;
  whyItMatters: string;
  actionAdvice: string;
}

export interface ParsedUpiDetails {
  rawPayload: string;
  isUpiScheme: boolean;
  payeeVpa?: string;
  payeeName?: string;
  requestedAmount?: string;
  transactionNote?: string;
  transactionRef?: string;
  currency?: string;
  unverifiedFields: string[];
}

export interface ParsedUrlDetails {
  rawUrl: string;
  isValid: boolean;
  protocol?: string;
  hostname?: string;
  isIpAddress?: boolean;
  isShortener?: boolean;
  hasLookalikeBrands?: boolean;
  brandImpersonated?: string;
  queryParamsCount?: number;
  warnings: string[];
}

export interface AnalysisInput {
  mode: 'message' | 'link' | 'qr' | 'payment_details';
  text?: string;
  url?: string;
  qrPayload?: string;
  qrImageFileName?: string;
  recipientVpa?: string;
  recipientName?: string;
  amount?: string;
  intent: UserIntent;
  isNewRecipient?: boolean;
}

export interface AnalysisResult {
  riskScore: number; // 0 to 100
  riskLevel: RiskLevel;
  isCriticalOverride: boolean;
  headlineVerdict: string;
  summaryAdvice: string;
  strongestIndicator?: RiskIndicator;
  indicators: RiskIndicator[];
  unverifiedLimitations: string[];
  recommendedNextAction: string;
  intentContext: UserIntent;
  timestamp: number;
  parsedUpi?: ParsedUpiDetails;
  parsedUrl?: ParsedUrlDetails;
}

export interface DemoScenario {
  id: string;
  title: string;
  type: string;
  intent: UserIntent;
  description: string;
  input: AnalysisInput;
  keyLearning: string;
}
