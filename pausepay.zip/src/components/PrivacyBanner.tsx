import React from 'react';
import { Lock, ShieldCheck, Info } from 'lucide-react';
import { useTranslation } from '../i18n/LanguageContext.tsx';

export const PrivacyBanner: React.FC = () => {
  const { t } = useTranslation();

  return (
    <aside aria-label="Privacy Guarantee" className="bg-slate-900/90 border-b border-slate-800 py-2 px-4">
      <div className="max-w-7xl mx-auto flex flex-wrap items-center justify-between gap-2 text-xs text-slate-400">
        <div className="flex items-center gap-2">
          <div className="flex items-center justify-center w-5 h-5 rounded-full bg-emerald-500/10 text-emerald-400 border border-emerald-500/30">
            <Lock className="w-3 h-3" />
          </div>
          <span className="font-medium text-slate-300">
            {t.privacyGuarantee}
          </span>
        </div>
        <div className="flex items-center gap-4 text-[11px] text-slate-400">
          <span className="inline-flex items-center gap-1">
            <ShieldCheck className="w-3.5 h-3.5 text-teal-400" />
            No Bank Connection
          </span>
          <span className="inline-flex items-center gap-1">
            <ShieldCheck className="w-3.5 h-3.5 text-teal-400" />
            No PIN Storage
          </span>
          <span className="inline-flex items-center gap-1">
            <Info className="w-3.5 h-3.5 text-cyan-400" />
            Synthetic Sandbox
          </span>
        </div>
      </div>
    </aside>
  );
};
