import React, { useState } from 'react';
import {
  MessageSquare,
  Link2,
  QrCode,
  CreditCard,
  Upload,
  RefreshCw,
  Search,
  CheckCircle,
  HelpCircle,
  AlertCircle,
  FileText,
} from 'lucide-react';
import { AnalysisInput, UserIntent } from '../types/index.ts';
import { useTranslation } from '../i18n/LanguageContext.tsx';
import { decodeQrFromImageFile } from '../engine/qrAnalyzer.ts';
import { DEMO_SCENARIOS } from '../engine/scenarios.ts';

interface AnalyzerWorkspaceProps {
  onAnalyze: (input: AnalysisInput) => void;
  onReset: () => void;
  currentInput: AnalysisInput;
  setCurrentInput: React.Dispatch<React.SetStateAction<AnalysisInput>>;
}

export const AnalyzerWorkspace: React.FC<AnalyzerWorkspaceProps> = ({
  onAnalyze,
  onReset,
  currentInput,
  setCurrentInput,
}) => {
  const { t } = useTranslation();
  const [errorMessage, setErrorMessage] = useState<string | null>(null);
  const [qrDecoding, setQrDecoding] = useState<boolean>(false);
  const [qrSuccessMessage, setQrSuccessMessage] = useState<string | null>(null);

  const handleModeChange = (mode: AnalysisInput['mode']) => {
    setErrorMessage(null);
    setQrSuccessMessage(null);
    setCurrentInput((prev) => ({
      ...prev,
      mode,
    }));
  };

  const handleIntentChange = (intent: UserIntent) => {
    setCurrentInput((prev) => ({
      ...prev,
      intent,
    }));
  };

  const handleQrFileUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    setQrDecoding(true);
    setErrorMessage(null);
    setQrSuccessMessage(null);

    try {
      const decodedPayload = await decodeQrFromImageFile(file);
      setCurrentInput((prev) => ({
        ...prev,
        qrPayload: decodedPayload,
        qrImageFileName: file.name,
      }));
      setQrSuccessMessage(`Decoded QR successfully: ${file.name}`);
    } catch (err: unknown) {
      const msg = err instanceof Error ? err.message : String(err);
      setErrorMessage(msg);
    } finally {
      setQrDecoding(false);
    }
  };

  const handleQuickLoad = (scenarioId: string) => {
    const found = DEMO_SCENARIOS.find((s) => s.id === scenarioId);
    if (!found) return;
    setErrorMessage(null);
    setQrSuccessMessage(null);
    setCurrentInput({ ...found.input });
    // Also trigger immediate analysis for seamless demo
    onAnalyze({ ...found.input });
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMessage(null);

    // Basic validation
    const hasText = currentInput.text && currentInput.text.trim().length > 0;
    const hasUrl = currentInput.url && currentInput.url.trim().length > 0;
    const hasQr = currentInput.qrPayload && currentInput.qrPayload.trim().length > 0;
    const hasRecipient = currentInput.recipientVpa && currentInput.recipientVpa.trim().length > 0;

    if (!hasText && !hasUrl && !hasQr && !hasRecipient) {
      setErrorMessage('Please provide a message, URL, QR code, or recipient details to analyze.');
      return;
    }

    onAnalyze(currentInput);
  };

  const handleClear = () => {
    setErrorMessage(null);
    setQrSuccessMessage(null);
    onReset();
  };

  return (
    <div className="bg-slate-900 border border-slate-800 rounded-3xl p-4 sm:p-6 shadow-xl mb-8">
      {/* Workspace Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 mb-6 pb-4 border-b border-slate-800">
        <div>
          <h2 className="text-xl sm:text-2xl font-bold text-white flex items-center gap-2">
            <span>Payment Safety Analyzer</span>
          </h2>
          <p className="text-xs sm:text-sm text-slate-400">
            Select your intent, paste details, and evaluate fraud risk before authorizing payment.
          </p>
        </div>

        {/* Quick Demo Pre-load buttons */}
        <div className="flex flex-wrap items-center gap-1.5">
          <span className="text-[11px] font-semibold text-slate-400 uppercase tracking-wider mr-1">
            Quick Load:
          </span>
          <button
            type="button"
            onClick={() => handleQuickLoad('scenario_normal_grocery')}
            className="text-xs px-2.5 py-1 rounded-lg bg-slate-800 hover:bg-slate-700 text-teal-300 border border-slate-700 transition cursor-pointer"
          >
            Grocery (Normal)
          </button>
          <button
            type="button"
            onClick={() => handleQuickLoad('scenario_pin_receive_cashback')}
            className="text-xs px-2.5 py-1 rounded-lg bg-rose-950/60 hover:bg-rose-900/60 text-rose-300 border border-rose-800/50 transition cursor-pointer"
          >
            Cashback Scam
          </button>
          <button
            type="button"
            onClick={() => handleQuickLoad('scenario_bank_impersonation')}
            className="text-xs px-2.5 py-1 rounded-lg bg-amber-950/60 hover:bg-amber-900/60 text-amber-300 border border-amber-800/50 transition cursor-pointer"
          >
            Bank Threat
          </button>
        </div>
      </div>

      <form onSubmit={handleSubmit}>
        {/* Step 1: User Payment Intent Selector */}
        <div className="mb-5 bg-slate-950/60 border border-slate-800/80 rounded-2xl p-4">
          <div className="flex items-center gap-2 mb-2.5">
            <HelpCircle className="w-4 h-4 text-teal-400" />
            <label htmlFor="intent-select" className="text-xs sm:text-sm font-semibold text-slate-200">
              {t.intentLabel}
            </label>
            <span className="text-[10px] uppercase font-bold tracking-wider px-2 py-0.5 rounded-full bg-teal-500/20 text-teal-300 border border-teal-500/30 ml-auto">
              Intent-Aware Engine
            </span>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-2">
            {[
              { id: 'send_money', label: t.intents.send_money, desc: 'Paying shopkeeper, bill, or contact' },
              { id: 'receive_money', label: t.intents.receive_money, desc: 'Expecting payment, lottery, or refund' },
              { id: 'scan_qr', label: t.intents.scan_qr, desc: 'Scanning QR at counter or on screen' },
              { id: 'review_request', label: t.intents.review_request, desc: 'Checking an incoming collect notification' },
              { id: 'verify_message', label: t.intents.verify_message, desc: 'SMS/WhatsApp claiming account block/offer' },
              { id: 'understand_instruction', label: t.intents.understand_instruction, desc: 'Someone asking me to follow steps' },
            ].map((item) => (
              <button
                key={item.id}
                type="button"
                onClick={() => handleIntentChange(item.id as UserIntent)}
                className={`text-left p-2.5 rounded-xl border text-xs transition-all cursor-pointer ${
                  currentInput.intent === item.id
                    ? 'bg-teal-500/10 border-teal-500 text-teal-200 font-medium shadow-sm'
                    : 'bg-slate-900/60 border-slate-800 text-slate-300 hover:border-slate-700'
                }`}
              >
                <div className="font-semibold text-slate-200 mb-0.5 flex items-center justify-between">
                  <span>{item.label}</span>
                  {currentInput.intent === item.id && (
                    <CheckCircle className="w-3.5 h-3.5 text-teal-400 shrink-0" />
                  )}
                </div>
                <div className="text-[11px] text-slate-400 leading-tight">{item.desc}</div>
              </button>
            ))}
          </div>
        </div>

        {/* Step 2: Mode Selector Tabs */}
        <div className="flex flex-wrap gap-2 mb-4">
          <button
            type="button"
            onClick={() => handleModeChange('message')}
            className={`flex items-center gap-2 px-3.5 py-2 rounded-xl text-xs sm:text-sm font-semibold transition cursor-pointer ${
              currentInput.mode === 'message'
                ? 'bg-teal-500 text-slate-950 shadow-md shadow-teal-500/20'
                : 'bg-slate-800 text-slate-300 hover:bg-slate-700'
            }`}
          >
            <MessageSquare className="w-4 h-4" />
            <span>{t.modeMessage}</span>
          </button>

          <button
            type="button"
            onClick={() => handleModeChange('link')}
            className={`flex items-center gap-2 px-3.5 py-2 rounded-xl text-xs sm:text-sm font-semibold transition cursor-pointer ${
              currentInput.mode === 'link'
                ? 'bg-teal-500 text-slate-950 shadow-md shadow-teal-500/20'
                : 'bg-slate-800 text-slate-300 hover:bg-slate-700'
            }`}
          >
            <Link2 className="w-4 h-4" />
            <span>{t.modeLink}</span>
          </button>

          <button
            type="button"
            onClick={() => handleModeChange('qr')}
            className={`flex items-center gap-2 px-3.5 py-2 rounded-xl text-xs sm:text-sm font-semibold transition cursor-pointer ${
              currentInput.mode === 'qr'
                ? 'bg-teal-500 text-slate-950 shadow-md shadow-teal-500/20'
                : 'bg-slate-800 text-slate-300 hover:bg-slate-700'
            }`}
          >
            <QrCode className="w-4 h-4" />
            <span>{t.modeQr}</span>
          </button>

          <button
            type="button"
            onClick={() => handleModeChange('payment_details')}
            className={`flex items-center gap-2 px-3.5 py-2 rounded-xl text-xs sm:text-sm font-semibold transition cursor-pointer ${
              currentInput.mode === 'payment_details'
                ? 'bg-teal-500 text-slate-950 shadow-md shadow-teal-500/20'
                : 'bg-slate-800 text-slate-300 hover:bg-slate-700'
            }`}
          >
            <CreditCard className="w-4 h-4" />
            <span>{t.modeDetails}</span>
          </button>
        </div>

        {/* Step 3: Input Area based on Mode */}
        <div className="mb-4">
          {/* Mode 1: Message Analysis */}
          {currentInput.mode === 'message' && (
            <div>
              <label htmlFor="message-input" className="block text-xs font-semibold text-slate-300 mb-1.5">
                Payment Message / SMS / WhatsApp Text
              </label>
              <textarea
                id="message-input"
                rows={4}
                value={currentInput.text || ''}
                onChange={(e) =>
                  setCurrentInput((prev) => ({
                    ...prev,
                    text: e.target.value,
                  }))
                }
                placeholder={t.samplePlaceholderMsg}
                className="w-full bg-slate-950 border border-slate-700 rounded-xl px-4 py-3 text-sm text-slate-100 placeholder-slate-500 focus:outline-none focus:border-teal-500 focus:ring-1 focus:ring-teal-500 transition leading-relaxed resize-y"
              />
            </div>
          )}

          {/* Mode 2: Link Analysis */}
          {currentInput.mode === 'link' && (
            <div className="space-y-3">
              <div>
                <label htmlFor="url-input" className="block text-xs font-semibold text-slate-300 mb-1.5">
                  Suspicious Payment or Verification URL
                </label>
                <div className="relative">
                  <Link2 className="w-4 h-4 text-slate-400 absolute left-3.5 top-3.5" />
                  <input
                    id="url-input"
                    type="text"
                    value={currentInput.url || ''}
                    onChange={(e) =>
                      setCurrentInput((prev) => ({
                        ...prev,
                        url: e.target.value,
                      }))
                    }
                    placeholder={t.samplePlaceholderLink}
                    className="w-full bg-slate-950 border border-slate-700 rounded-xl pl-10 pr-4 py-3 text-sm text-slate-100 placeholder-slate-500 focus:outline-none focus:border-teal-500 focus:ring-1 focus:ring-teal-500 transition"
                  />
                </div>
              </div>
              <div>
                <label htmlFor="link-context-input" className="block text-xs font-semibold text-slate-300 mb-1.5">
                  Accompanying Message or Context (Optional)
                </label>
                <input
                  id="link-context-input"
                  type="text"
                  value={currentInput.text || ''}
                  onChange={(e) =>
                    setCurrentInput((prev) => ({
                      ...prev,
                      text: e.target.value,
                    }))
                  }
                  placeholder="e.g. Sent via SMS claiming bank account block"
                  className="w-full bg-slate-950 border border-slate-700 rounded-xl px-4 py-2.5 text-xs sm:text-sm text-slate-100 placeholder-slate-500 focus:outline-none focus:border-teal-500"
                />
              </div>
              <p className="text-[11px] text-slate-400 italic">
                Note: Links are analyzed 100% locally in browser memory. PausePay never opens or sends requests to submitted URLs.
              </p>
            </div>
          )}

          {/* Mode 3: QR Code Analysis */}
          {currentInput.mode === 'qr' && (
            <div className="space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                {/* Local file upload */}
                <div className="border-2 border-dashed border-slate-700 rounded-2xl p-4 text-center bg-slate-950/40 hover:border-teal-500/60 transition">
                  <input
                    type="file"
                    id="qr-file-upload"
                    accept="image/*"
                    onChange={handleQrFileUpload}
                    className="hidden"
                  />
                  <label
                    htmlFor="qr-file-upload"
                    className="flex flex-col items-center justify-center cursor-pointer"
                  >
                    <Upload className="w-8 h-8 text-teal-400 mb-2" />
                    <span className="text-xs font-semibold text-slate-200">
                      Upload QR Image (PNG/JPG)
                    </span>
                    <span className="text-[11px] text-slate-400 mt-1">
                      Processed locally via canvas. Never uploaded to servers.
                    </span>
                  </label>
                  {qrDecoding && (
                    <div className="mt-2 text-xs text-teal-400 flex items-center justify-center gap-1.5">
                      <RefreshCw className="w-3.5 h-3.5 animate-spin" />
                      <span>Decoding QR image locally...</span>
                    </div>
                  )}
                  {qrSuccessMessage && (
                    <div className="mt-2 text-xs text-emerald-400 flex items-center justify-center gap-1">
                      <CheckCircle className="w-3.5 h-3.5" />
                      <span>{qrSuccessMessage}</span>
                    </div>
                  )}
                </div>

                {/* Manual payload paste fallback */}
                <div className="flex flex-col justify-between">
                  <label htmlFor="qr-payload-input" className="block text-xs font-semibold text-slate-300 mb-1">
                    Or Paste Decoded UPI QR Payload Manually:
                  </label>
                  <textarea
                    id="qr-payload-input"
                    rows={3}
                    value={currentInput.qrPayload || ''}
                    onChange={(e) =>
                      setCurrentInput((prev) => ({
                        ...prev,
                        qrPayload: e.target.value,
                      }))
                    }
                    placeholder={t.samplePlaceholderQr}
                    className="w-full bg-slate-950 border border-slate-700 rounded-xl px-3 py-2 text-xs text-slate-100 placeholder-slate-500 focus:outline-none focus:border-teal-500 font-mono resize-none"
                  />
                  <div className="flex items-center gap-2 mt-2">
                    <button
                      type="button"
                      onClick={() =>
                        setCurrentInput((prev) => ({
                          ...prev,
                          qrPayload:
                            'upi://pay?pa=cashback_claims@okhdfcbank&pn=MegaRewards&am=5000&cu=INR&tn=Cashback%20Reward',
                          intent: 'receive_money',
                        }))
                      }
                      className="text-[11px] text-teal-400 hover:underline cursor-pointer"
                    >
                      Paste Sample Trap QR (Pay instead of Receive)
                    </button>
                  </div>
                </div>
              </div>

              {/* Accompanying text */}
              <div>
                <label htmlFor="qr-text-input" className="block text-xs font-semibold text-slate-300 mb-1">
                  Accompanying Verbal or Written Instructions (e.g. "Enter PIN to receive")
                </label>
                <input
                  id="qr-text-input"
                  type="text"
                  value={currentInput.text || ''}
                  onChange={(e) =>
                    setCurrentInput((prev) => ({
                      ...prev,
                      text: e.target.value,
                    }))
                  }
                  placeholder="e.g. Someone told me to scan this QR and enter my PIN to get ₹5,000"
                  className="w-full bg-slate-950 border border-slate-700 rounded-xl px-4 py-2.5 text-xs sm:text-sm text-slate-100 placeholder-slate-500 focus:outline-none focus:border-teal-500"
                />
              </div>
            </div>
          )}

          {/* Mode 4: Payment Details */}
          {currentInput.mode === 'payment_details' && (
            <div className="space-y-3">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label htmlFor="recipient-vpa-input" className="block text-xs font-semibold text-slate-300 mb-1">
                    {t.recipientVpaLabel}
                  </label>
                  <input
                    id="recipient-vpa-input"
                    type="text"
                    value={currentInput.recipientVpa || ''}
                    onChange={(e) =>
                      setCurrentInput((prev) => ({
                        ...prev,
                        recipientVpa: e.target.value,
                      }))
                    }
                    placeholder="e.g. merchant@okhdfcbank or 9876543210@paytm"
                    className="w-full bg-slate-950 border border-slate-700 rounded-xl px-4 py-2.5 text-xs sm:text-sm text-slate-100 placeholder-slate-500 focus:outline-none focus:border-teal-500 font-mono"
                  />
                </div>
                <div>
                  <label htmlFor="recipient-name-input" className="block text-xs font-semibold text-slate-300 mb-1">
                    {t.recipientNameLabel}
                  </label>
                  <input
                    id="recipient-name-input"
                    type="text"
                    value={currentInput.recipientName || ''}
                    onChange={(e) =>
                      setCurrentInput((prev) => ({
                        ...prev,
                        recipientName: e.target.value,
                      }))
                    }
                    placeholder="e.g. Super Grocers Store"
                    className="w-full bg-slate-950 border border-slate-700 rounded-xl px-4 py-2.5 text-xs sm:text-sm text-slate-100 placeholder-slate-500 focus:outline-none focus:border-teal-500"
                  />
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 items-center">
                <div>
                  <label htmlFor="amount-input" className="block text-xs font-semibold text-slate-300 mb-1">
                    {t.amountLabel}
                  </label>
                  <input
                    id="amount-input"
                    type="number"
                    value={currentInput.amount || ''}
                    onChange={(e) =>
                      setCurrentInput((prev) => ({
                        ...prev,
                        amount: e.target.value,
                      }))
                    }
                    placeholder="450"
                    className="w-full bg-slate-950 border border-slate-700 rounded-xl px-4 py-2.5 text-xs sm:text-sm text-slate-100 placeholder-slate-500 focus:outline-none focus:border-teal-500"
                  />
                </div>

                <div className="pt-4">
                  <label className="flex items-center gap-2 cursor-pointer select-none">
                    <input
                      type="checkbox"
                      checked={currentInput.isNewRecipient || false}
                      onChange={(e) =>
                        setCurrentInput((prev) => ({
                          ...prev,
                          isNewRecipient: e.target.checked,
                        }))
                      }
                      className="w-4 h-4 rounded border-slate-700 text-teal-500 focus:ring-teal-500 bg-slate-950 cursor-pointer"
                    />
                    <span className="text-xs text-slate-300">
                      {t.firstTimeRecipientCheck}
                    </span>
                  </label>
                </div>
              </div>
            </div>
          )}
        </div>

        {/* Error Notification */}
        {errorMessage && (
          <div className="mb-4 p-3 rounded-xl bg-rose-950/60 border border-rose-800 text-rose-300 text-xs flex items-center gap-2">
            <AlertCircle className="w-4 h-4 shrink-0" />
            <span>{errorMessage}</span>
          </div>
        )}

        {/* Bottom Actions: Submit and Reset */}
        <div className="flex flex-wrap items-center justify-between gap-3 pt-2">
          <button
            type="submit"
            className="px-6 py-3 rounded-xl bg-teal-500 hover:bg-teal-400 text-slate-950 font-bold text-sm shadow-lg shadow-teal-500/20 transition flex items-center gap-2 cursor-pointer"
          >
            <Search className="w-4 h-4 stroke-[2.5]" />
            <span>{t.checkRiskBtn}</span>
          </button>

          <button
            type="button"
            onClick={handleClear}
            className="px-4 py-2.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 hover:text-white text-xs font-semibold border border-slate-700 transition flex items-center gap-1.5 cursor-pointer"
          >
            <RefreshCw className="w-3.5 h-3.5" />
            <span>{t.resetBtn}</span>
          </button>
        </div>
      </form>
    </div>
  );
};
