import React from 'react';
import { X, CheckCircle, AlertTriangle, ShieldAlert, Info, Sparkles, Scale } from 'lucide-react';
import { AnalysisResult } from '../types/index.ts';

interface ExplainabilityDrawerProps {
  result: AnalysisResult;
  isOpen: boolean;
  onClose: () => void;
}

export const ExplainabilityDrawer: React.FC<ExplainabilityDrawerProps> = ({
  result,
  isOpen,
  onClose,
}) => {
  if (!isOpen) return null;

  return (
    <div
      role="dialog"
      aria-modal="true"
      aria-labelledby="explainability-title"
      className="fixed inset-0 z-50 flex justify-end bg-slate-950/70 backdrop-blur-sm animate-fade-in"
    >
      <div className="w-full max-w-2xl bg-slate-900 border-l border-slate-800 h-full overflow-y-auto text-white p-6 sm:p-8 flex flex-col justify-between shadow-2xl">
        <div>
          {/* Header */}
          <div className="flex items-center justify-between pb-5 border-b border-slate-800 mb-6">
            <div>
              <div className="flex items-center gap-2 mb-1">
                <span className="text-[11px] font-black uppercase tracking-widest text-teal-400">
                  Explainable Risk Engine
                </span>
                <span className="text-xs bg-slate-800 text-slate-300 px-2 py-0.5 rounded-full border border-slate-700">
                  Deterministic Heuristics
                </span>
              </div>
              <h2 id="explainability-title" className="text-xl sm:text-2xl font-black text-white">
                Why this result? (Signal Breakdown)
              </h2>
            </div>
            <button
              onClick={onClose}
              aria-label="Close Explainability Drawer"
              className="text-slate-400 hover:text-white p-2 rounded-xl hover:bg-slate-800 transition cursor-pointer"
            >
              <X className="w-6 h-6" />
            </button>
          </div>

          {/* Engine Scoring Mechanics Overview */}
          <div className="bg-slate-950 border border-slate-800 rounded-2xl p-4 mb-6">
            <div className="flex items-center justify-between text-xs mb-2">
              <span className="font-bold text-slate-300 flex items-center gap-1.5">
                <Scale className="w-4 h-4 text-teal-400" />
                <span>Scoring Calculation</span>
              </span>
              <span className="font-mono font-bold text-teal-400">
                Calculated Score: {result.riskScore}/100
              </span>
            </div>
            <p className="text-xs text-slate-400 leading-relaxed mb-3">
              PausePay analyzes observed wording, context, and structural payloads without making external network calls.
              {result.isCriticalOverride ? (
                <span className="text-rose-400 font-bold block mt-1">
                  * Mandatory Critical Override Applied: When a message asks for your UPI PIN to receive money or requests credential disclosure, the score is pinned to Critical (≥95) regardless of other words.
                </span>
              ) : (
                <span className="text-slate-300 block mt-1">
                  Arithmetic score combines individual deduplicated indicators capped between 0 and 100.
                </span>
              )}
            </p>
            <div className="text-[11px] text-slate-400 flex items-center gap-3">
              <span>Intent Context: <strong className="text-white">{result.intentContext}</strong></span>
              <span>•</span>
              <span>Signals Detected: <strong className="text-white">{result.indicators.length}</strong></span>
            </div>
          </div>

          {/* Indicator Cards */}
          <div className="space-y-4 mb-6">
            <h3 className="text-xs font-bold uppercase tracking-wider text-slate-400">
              Detected Warning Indicators & Evidence:
            </h3>

            {result.indicators.length === 0 ? (
              <div className="bg-slate-950/60 border border-slate-800 rounded-2xl p-5 text-center text-slate-400 text-xs">
                <CheckCircle className="w-8 h-8 text-emerald-400 mx-auto mb-2" />
                <p className="font-semibold text-slate-200 mb-1">
                  No Suspicious Warning Indicators Triggered
                </p>
                <p className="text-slate-400 max-w-sm mx-auto">
                  The input did not contain coercive threats, urgent deadlines, PIN-to-receive instructions, or suspicious URLs. Always verify the recipient and amount independently before authorizing payment.
                </p>
              </div>
            ) : (
              result.indicators.map((indicator, index) => {
                const isCrit = indicator.severity === 'critical';
                const isHigh = indicator.severity === 'high';
                return (
                  <div
                    key={indicator.id + index}
                    className={`p-4 sm:p-5 rounded-2xl border transition-all ${
                      isCrit
                        ? 'bg-rose-950/25 border-rose-800/80'
                        : isHigh
                        ? 'bg-orange-950/25 border-orange-800/80'
                        : 'bg-slate-950 border-slate-800'
                    }`}
                  >
                    {/* Header: Name, Severity, Contribution */}
                    <div className="flex flex-wrap items-center justify-between gap-2 mb-2.5">
                      <div className="flex items-center gap-2">
                        {isCrit ? (
                          <ShieldAlert className="w-4 h-4 text-rose-400" />
                        ) : isHigh ? (
                          <AlertTriangle className="w-4 h-4 text-orange-400" />
                        ) : (
                          <Info className="w-4 h-4 text-amber-400" />
                        )}
                        <h4 className="font-extrabold text-sm sm:text-base text-white">
                          {indicator.name}
                        </h4>
                      </div>
                      <div className="flex items-center gap-1.5">
                        <span
                          className={`text-[10px] uppercase font-bold tracking-wider px-2 py-0.5 rounded-full border ${
                            isCrit
                              ? 'bg-rose-500/20 text-rose-300 border-rose-500/40'
                              : isHigh
                              ? 'bg-orange-500/20 text-orange-300 border-orange-500/40'
                              : 'bg-amber-500/20 text-amber-300 border-amber-500/40'
                          }`}
                        >
                          {indicator.severity}
                        </span>
                        <span className="text-xs font-mono text-teal-400 bg-slate-900 px-2 py-0.5 rounded border border-slate-700">
                          {isCrit ? 'Override' : `+${indicator.scoreContribution} pts`}
                        </span>
                      </div>
                    </div>

                    {/* Matched Evidence */}
                    <div className="bg-slate-900/90 rounded-xl p-3 border border-slate-800 mb-3">
                      <span className="text-[10px] font-bold uppercase tracking-wider text-slate-400 block mb-1">
                        Observable Evidence Found in Input:
                      </span>
                      <p className="text-xs sm:text-sm font-mono text-teal-200 break-words">
                        "{indicator.evidence}"
                      </p>
                    </div>

                    {/* Why it Matters */}
                    <div className="mb-2.5 text-xs text-slate-300 leading-relaxed">
                      <strong className="text-slate-200 block mb-0.5">Why it matters:</strong>
                      {indicator.whyItMatters}
                    </div>

                    {/* Action Advice */}
                    <div className="text-xs text-emerald-300 bg-emerald-950/30 border border-emerald-800/40 p-2.5 rounded-xl">
                      <strong className="text-emerald-200 block mb-0.5">Safe Next Step:</strong>
                      {indicator.actionAdvice}
                    </div>
                  </div>
                );
              })
            )}
          </div>

          {/* Limitations Disclosure */}
          <div className="bg-slate-950/80 border border-slate-800 rounded-2xl p-4 text-xs text-slate-400 space-y-2 mb-6">
            <div className="font-bold text-slate-200 flex items-center gap-1.5">
              <Info className="w-4 h-4 text-cyan-400" />
              <span>Limitations of Heuristic Analysis</span>
            </div>
            <p>
              PausePay evaluates observable text indicators, URI patterns, and intent mismatches. It does not possess direct connectivity to NPCI core banking switches or account balance databases.
            </p>
            <p className="text-slate-400 italic">
              Absence of detected indicators is NOT proof of legitimacy. Attackers can compose persuasive, grammatically correct messages without urgent keywords.
            </p>
          </div>
        </div>

        {/* Drawer Footer */}
        <div className="pt-4 border-t border-slate-800">
          <button
            type="button"
            onClick={onClose}
            className="w-full py-3 rounded-xl bg-slate-800 hover:bg-slate-700 text-white font-bold text-sm border border-slate-700 transition cursor-pointer"
          >
            Close Breakdown
          </button>
        </div>
      </div>
    </div>
  );
};
