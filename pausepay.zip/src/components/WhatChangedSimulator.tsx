import React, { useState } from 'react';
import { ArrowRight, GitCompare, AlertTriangle, ShieldCheck, ShieldAlert, Sparkles, RefreshCw, Info } from 'lucide-react';
import { evaluateRisk } from '../engine/riskEngine.ts';
import { AnalysisResult } from '../types/index.ts';
import { useTranslation } from '../i18n/LanguageContext.tsx';

interface ComparisonPair {
  id: string;
  title: string;
  description: string;
  msgA: string;
  msgB: string;
}

const PRESET_PAIRS: ComparisonPair[] = [
  {
    id: 'pair_bank_threat',
    title: 'Account Suspension Threat vs Official Notice',
    description: 'See how urgent threats and deceptive links create high risk compared to standard bank advisories.',
    msgA: 'ALERT: Your bank account will be blocked in 10 minutes. Pay a verification fee immediately using this link: http://sbi-kyc-verify.top/pay',
    msgB: 'Security Advisory: Periodic KYC update can be completed safely through your official NetBanking app or nearest branch. Never share OTP or PIN.',
  },
  {
    id: 'pair_pin_receive',
    title: 'Reward PIN-to-Receive Trap vs Legitimate Cashback Notice',
    description: 'Observe how demanding a PIN to receive money triggers a critical override compared to genuine direct bank credit.',
    msgA: 'Congratulations! You have won ₹5,000 cashback reward. Scan QR code and enter your UPI PIN to claim reward within 5 minutes.',
    msgB: 'You have earned ₹50 cashback on your last grocery transaction. The amount of ₹50 has been credited directly to your HDFC bank account.',
  },
  {
    id: 'pair_remote_support',
    title: 'AnyDesk Screen-Share Trap vs Official Support',
    description: 'Notice the massive score jump when remote-access software is requested alongside banking.',
    msgA: 'Customer care: Your refund of ₹1,400 is held. Please install AnyDesk support app, share your 9-digit code, and keep your UPI app open.',
    msgB: 'Customer care: Your refund request has been registered under ticket #7821. It will be credited back to your original source of payment within 3-5 business days.',
  },
];

export const WhatChangedSimulator: React.FC = () => {
  const { t } = useTranslation();
  const [selectedPairId, setSelectedPairId] = useState<string>('pair_bank_threat');
  const [textA, setTextA] = useState<string>(PRESET_PAIRS[0].msgA);
  const [textB, setTextB] = useState<string>(PRESET_PAIRS[0].msgB);

  // Compute evaluations dynamically through the real risk engine!
  const resultA: AnalysisResult = evaluateRisk({
    mode: 'message',
    text: textA,
    intent: 'verify_message',
  });

  const resultB: AnalysisResult = evaluateRisk({
    mode: 'message',
    text: textB,
    intent: 'verify_message',
  });

  const handleSelectPair = (pair: ComparisonPair) => {
    setSelectedPairId(pair.id);
    setTextA(pair.msgA);
    setTextB(pair.msgB);
  };

  const scoreDelta = resultA.riskScore - resultB.riskScore;

  return (
    <div className="bg-slate-900 border border-slate-800 rounded-3xl p-4 sm:p-7 shadow-2xl mb-8">
      {/* Title & Concept */}
      <div className="mb-6 pb-4 border-b border-slate-800">
        <div className="flex items-center gap-2 mb-1">
          <GitCompare className="w-5 h-5 text-teal-400" />
          <h2 className="text-xl sm:text-2xl font-black text-white">
            {t.whatChangedTitle}
          </h2>
          <span className="text-[10px] uppercase font-bold tracking-wider px-2 py-0.5 rounded-full bg-teal-500/20 text-teal-300 border border-teal-500/30">
            Interactive Learning
          </span>
        </div>
        <p className="text-xs sm:text-sm text-slate-300 leading-relaxed max-w-3xl">
          {t.whatChangedSubtitle}
        </p>
      </div>

      {/* Preset Pairs Selector */}
      <div className="mb-6">
        <label className="block text-xs font-bold uppercase tracking-wider text-slate-400 mb-2">
          Select a Comparison Scenario:
        </label>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-2.5">
          {PRESET_PAIRS.map((pair) => (
            <button
              key={pair.id}
              onClick={() => handleSelectPair(pair)}
              className={`p-3 rounded-2xl border text-left text-xs transition cursor-pointer ${
                selectedPairId === pair.id
                  ? 'bg-teal-500/10 border-teal-500 text-teal-200'
                  : 'bg-slate-950 border-slate-800 text-slate-300 hover:border-slate-700'
              }`}
            >
              <div className="font-bold text-slate-200 mb-1">{pair.title}</div>
              <div className="text-[11px] text-slate-400 leading-tight line-clamp-2">
                {pair.description}
              </div>
            </button>
          ))}
        </div>
      </div>

      {/* Delta Summary Bar */}
      <div className="bg-slate-950 border border-slate-800 rounded-2xl p-4 mb-6 flex flex-wrap items-center justify-between gap-4">
        <div className="flex items-center gap-3">
          <div className="flex items-center justify-center w-10 h-10 rounded-xl bg-slate-900 border border-slate-700 font-black text-sm">
            Δ
          </div>
          <div>
            <div className="text-xs font-bold uppercase tracking-wider text-slate-400">
              Risk Score Difference
            </div>
            <div className="text-sm font-semibold text-white">
              Version A scored <span className="text-rose-400 font-extrabold">{resultA.riskScore}</span> vs Version B scored <span className="text-emerald-400 font-extrabold">{resultB.riskScore}</span>
            </div>
          </div>
        </div>

        <div className="flex items-center gap-2">
          <span className="text-xs text-slate-400">Net Risk Reduction:</span>
          <span className={`text-base font-black px-3 py-1 rounded-xl ${
            scoreDelta > 0 ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/40' : 'bg-slate-800 text-slate-300'
          }`}>
            {scoreDelta > 0 ? `-${scoreDelta} pts` : `${scoreDelta} pts`}
          </span>
        </div>
      </div>

      {/* Side-by-Side Comparison Columns */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-5 mb-6">
        {/* Version A Card */}
        <div className="bg-slate-950 border-2 border-rose-900/60 rounded-2xl p-4 sm:p-5 flex flex-col justify-between">
          <div>
            <div className="flex items-center justify-between mb-3">
              <span className="text-xs font-black uppercase tracking-wider text-rose-400 flex items-center gap-1.5">
                <ShieldAlert className="w-4 h-4" />
                <span>Version A (Suspicious Variant)</span>
              </span>
              <span className="text-xs font-black px-2.5 py-0.5 rounded-full bg-rose-500/20 text-rose-300 border border-rose-500/40">
                Score: {resultA.riskScore}/100 ({resultA.riskLevel.toUpperCase()})
              </span>
            </div>

            <label htmlFor="msg-a-input" className="block text-[11px] text-slate-400 mb-1">
              Editable Message Text:
            </label>
            <textarea
              id="msg-a-input"
              rows={4}
              value={textA}
              onChange={(e) => setTextA(e.target.value)}
              className="w-full bg-slate-900 border border-slate-700 rounded-xl p-3 text-xs sm:text-sm text-slate-100 focus:outline-none focus:border-rose-500 resize-none font-medium mb-3"
            />

            {/* Indicators Triggered */}
            <div className="space-y-1.5 mb-3">
              <div className="text-[11px] font-bold text-slate-400 uppercase tracking-wider">
                Triggered Warning Signals ({resultA.indicators.length}):
              </div>
              {resultA.indicators.length === 0 ? (
                <div className="text-xs text-slate-400 italic">None</div>
              ) : (
                resultA.indicators.map((ind) => (
                  <div
                    key={ind.id}
                    className="flex items-center justify-between text-xs p-2 rounded-lg bg-rose-950/30 border border-rose-900/50 text-rose-200"
                  >
                    <span className="font-semibold">{ind.name}</span>
                    <span className="text-[10px] font-mono px-1.5 py-0.5 rounded bg-slate-900">
                      +{ind.scoreContribution}
                    </span>
                  </div>
                ))
              )}
            </div>
          </div>

          <div className="text-xs text-slate-400 bg-slate-900/60 p-2.5 rounded-xl border border-slate-800">
            <strong>Key verdict:</strong> {resultA.headlineVerdict}
          </div>
        </div>

        {/* Version B Card */}
        <div className="bg-slate-950 border-2 border-emerald-900/60 rounded-2xl p-4 sm:p-5 flex flex-col justify-between">
          <div>
            <div className="flex items-center justify-between mb-3">
              <span className="text-xs font-black uppercase tracking-wider text-emerald-400 flex items-center gap-1.5">
                <ShieldCheck className="w-4 h-4" />
                <span>Version B (Neutral / Official Variant)</span>
              </span>
              <span className="text-xs font-black px-2.5 py-0.5 rounded-full bg-emerald-500/20 text-emerald-300 border border-emerald-500/40">
                Score: {resultB.riskScore}/100 ({resultB.riskLevel.toUpperCase()})
              </span>
            </div>

            <label htmlFor="msg-b-input" className="block text-[11px] text-slate-400 mb-1">
              Editable Message Text:
            </label>
            <textarea
              id="msg-b-input"
              rows={4}
              value={textB}
              onChange={(e) => setTextB(e.target.value)}
              className="w-full bg-slate-900 border border-slate-700 rounded-xl p-3 text-xs sm:text-sm text-slate-100 focus:outline-none focus:border-emerald-500 resize-none font-medium mb-3"
            />

            {/* Indicators Triggered */}
            <div className="space-y-1.5 mb-3">
              <div className="text-[11px] font-bold text-slate-400 uppercase tracking-wider">
                Triggered Warning Signals ({resultB.indicators.length}):
              </div>
              {resultB.indicators.length === 0 ? (
                <div className="text-xs text-emerald-300/80 bg-emerald-950/20 border border-emerald-900/40 p-2 rounded-lg font-medium flex items-center gap-1.5">
                  <ShieldCheck className="w-3.5 h-3.5 text-emerald-400 shrink-0" />
                  <span>No suspicious indicators detected</span>
                </div>
              ) : (
                resultB.indicators.map((ind) => (
                  <div
                    key={ind.id}
                    className="flex items-center justify-between text-xs p-2 rounded-lg bg-slate-900 border border-slate-800 text-slate-200"
                  >
                    <span className="font-semibold">{ind.name}</span>
                    <span className="text-[10px] font-mono px-1.5 py-0.5 rounded bg-slate-800">
                      +{ind.scoreContribution}
                    </span>
                  </div>
                ))
              )}
            </div>
          </div>

          <div className="text-xs text-slate-400 bg-slate-900/60 p-2.5 rounded-xl border border-slate-800">
            <strong>Key verdict:</strong> {resultB.headlineVerdict}
          </div>
        </div>
      </div>

      {/* Critical Cybersecurity Limitation Box */}
      <div className="bg-amber-950/30 border border-amber-700/50 rounded-2xl p-4 text-xs text-amber-200/90 flex items-start gap-3">
        <Info className="w-5 h-5 text-amber-400 shrink-0 mt-0.5" />
        <div>
          <strong className="text-amber-300 block mb-0.5">
            Crucial Cybersecurity Principle:
          </strong>
          Removing threatening or urgent words does NOT prove that a message is safe or genuine. Sophisticated attackers frequently craft calm, courteous messages using legitimate-sounding banking jargon. Always authenticate sensitive requests directly via your official bank application or phone directory.
        </div>
      </div>
    </div>
  );
};
