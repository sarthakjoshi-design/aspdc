import React from 'react';
import { ArrowRight, AlertTriangle, ShieldCheck, Sparkles, CheckCircle2 } from 'lucide-react';
import { useTranslation } from '../i18n/LanguageContext.tsx';

interface HeroProps {
  onAnalyzeClick: () => void;
  onDemoClick: () => void;
  onWhatChangedClick: () => void;
}

export const Hero: React.FC<HeroProps> = ({ onAnalyzeClick, onDemoClick, onWhatChangedClick }) => {
  const { t } = useTranslation();

  return (
    <section className="relative overflow-hidden bg-gradient-to-b from-slate-900 via-slate-900 to-slate-950 text-white pt-10 pb-8 border-b border-slate-800">
      {/* Subtle decorative glow */}
      <div className="absolute top-0 left-1/2 -translate-x-1/2 w-3/4 h-48 bg-teal-500/10 blur-[100px] pointer-events-none" />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        <div className="text-center max-w-3xl mx-auto">
          {/* Tag pill */}
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-slate-800/80 border border-slate-700 text-teal-300 text-xs font-semibold mb-4 shadow-sm">
            <Sparkles className="w-3.5 h-3.5 text-teal-400" />
            <span>Cybersecurity Innovation · UPI Fraud Interceptor</span>
          </div>

          {/* Main Title */}
          <h1 className="text-3xl sm:text-5xl font-extrabold tracking-tight text-white mb-4 leading-tight">
            {t.heroHeadline}
          </h1>

          {/* Subheading */}
          <p className="text-base sm:text-lg text-slate-300 mb-6 leading-relaxed">
            {t.heroSubhead}
          </p>

          {/* Action CTAs */}
          <div className="flex flex-wrap items-center justify-center gap-3 mb-8">
            <button
              onClick={onAnalyzeClick}
              className="px-6 py-3 rounded-xl bg-teal-500 hover:bg-teal-400 text-slate-950 font-bold text-sm sm:text-base shadow-lg shadow-teal-500/25 transition-all flex items-center gap-2 cursor-pointer"
            >
              <span>{t.analyzeNow}</span>
              <ArrowRight className="w-4 h-4 stroke-[2.5]" />
            </button>
            <button
              onClick={onDemoClick}
              className="px-5 py-3 rounded-xl bg-slate-800 hover:bg-slate-700 text-white font-semibold text-sm sm:text-base border border-slate-700 transition-all flex items-center gap-2 cursor-pointer"
            >
              <span>{t.tryLiveDemo}</span>
            </button>
            <button
              onClick={onWhatChangedClick}
              className="px-4 py-3 rounded-xl bg-slate-800/60 hover:bg-slate-800 text-teal-300 font-semibold text-sm border border-teal-500/30 transition-all flex items-center gap-2 cursor-pointer"
            >
              <span>"What Changed?" Simulator</span>
            </button>
          </div>

          {/* Golden Rule Callout Box */}
          <div className="bg-amber-950/40 border border-amber-600/40 rounded-2xl p-4 sm:p-5 text-left flex flex-col sm:flex-row items-start sm:items-center gap-3.5 shadow-md">
            <div className="p-2.5 rounded-xl bg-amber-500/20 text-amber-300 border border-amber-500/40 shrink-0">
              <AlertTriangle className="w-6 h-6 text-amber-400" />
            </div>
            <div className="flex-1">
              <div className="text-xs font-bold uppercase tracking-wider text-amber-400 mb-0.5">
                The Golden Rule of UPI Safety
              </div>
              <p className="text-xs sm:text-sm text-amber-100 font-medium leading-snug">
                Entering a UPI PIN <strong className="text-white underline decoration-amber-400 font-extrabold">always DEBITS money</strong> from your bank account. You NEVER need to enter a PIN, scan a QR code, or approve a collect request to <strong className="text-white underline decoration-amber-400 font-extrabold">RECEIVE</strong> money, cashback, or refunds.
              </p>
            </div>
            <div className="hidden md:flex items-center gap-1.5 text-xs font-semibold text-emerald-400 bg-emerald-950/80 border border-emerald-700/50 px-3 py-1.5 rounded-xl shrink-0">
              <CheckCircle2 className="w-4 h-4" />
              <span>NPCI Safety Norm</span>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};
