import React from 'react';
import { ShieldCheck, ShieldAlert, PauseCircle, Globe, PhoneCall } from 'lucide-react';
import { useTranslation } from '../i18n/LanguageContext.tsx';
import { SupportedLanguage } from '../i18n/translations.ts';

interface NavbarProps {
  activeTab: 'analyze' | 'demolab' | 'whatchanged' | 'guide';
  setActiveTab: (tab: 'analyze' | 'demolab' | 'whatchanged' | 'guide') => void;
}

export const Navbar: React.FC<NavbarProps> = ({ activeTab, setActiveTab }) => {
  const { language, setLanguage, t } = useTranslation();

  return (
    <header className="sticky top-0 z-40 bg-slate-900 border-b border-slate-800 text-white shadow-md">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16">
          {/* Brand Logo & Wordmark */}
          <div
            className="flex items-center gap-3 cursor-pointer select-none"
            onClick={() => setActiveTab('analyze')}
            role="button"
            tabIndex={0}
            onKeyDown={(e) => e.key === 'Enter' && setActiveTab('analyze')}
            aria-label="PausePay Home"
          >
            <div className="w-10 h-10 rounded-xl bg-gradient-to-tr from-teal-500 to-emerald-400 flex items-center justify-center text-slate-950 font-black shadow-lg shadow-teal-500/20">
              <div className="flex items-center justify-center">
                <PauseCircle className="w-6 h-6 text-slate-950 stroke-[2.5]" />
              </div>
            </div>
            <div>
              <div className="flex items-center gap-2">
                <span className="font-extrabold text-xl tracking-tight text-white">PausePay</span>
                <span className="text-[11px] font-semibold uppercase tracking-wider bg-teal-500/20 text-teal-300 border border-teal-500/30 px-2 py-0.5 rounded-full">
                  UPI Safety
                </span>
              </div>
              <p className="text-xs text-slate-400 font-medium hidden sm:block">
                {t.tagline}
              </p>
            </div>
          </div>

          {/* Nav Tabs */}
          <nav className="hidden md:flex items-center gap-1">
            <button
              onClick={() => setActiveTab('analyze')}
              className={`px-3 py-2 rounded-lg text-sm font-medium transition-colors ${
                activeTab === 'analyze'
                  ? 'bg-slate-800 text-teal-400 border border-slate-700'
                  : 'text-slate-300 hover:text-white hover:bg-slate-800/60'
              }`}
            >
              {t.analyzeNow}
            </button>
            <button
              onClick={() => setActiveTab('demolab')}
              className={`px-3 py-2 rounded-lg text-sm font-medium transition-colors ${
                activeTab === 'demolab'
                  ? 'bg-slate-800 text-teal-400 border border-slate-700'
                  : 'text-slate-300 hover:text-white hover:bg-slate-800/60'
              }`}
            >
              Demo Lab (7)
            </button>
            <button
              onClick={() => setActiveTab('whatchanged')}
              className={`px-3 py-2 rounded-lg text-sm font-medium transition-colors ${
                activeTab === 'whatchanged'
                  ? 'bg-slate-800 text-teal-400 border border-slate-700'
                  : 'text-slate-300 hover:text-white hover:bg-slate-800/60'
              }`}
            >
              What Changed?
            </button>
            <button
              onClick={() => setActiveTab('guide')}
              className={`px-3 py-2 rounded-lg text-sm font-medium transition-colors ${
                activeTab === 'guide'
                  ? 'bg-slate-800 text-teal-400 border border-slate-700'
                  : 'text-slate-300 hover:text-white hover:bg-slate-800/60'
              }`}
            >
              Safety Guide
            </button>
          </nav>

          {/* Right Actions: Helpline & Language & Privacy Badge */}
          <div className="flex items-center gap-2 sm:gap-3">
            {/* National Helpline 1930 quick call / info */}
            <a
              href="tel:1930"
              className="inline-flex items-center gap-1.5 px-2.5 py-1.5 rounded-lg text-xs font-semibold bg-rose-500/10 text-rose-300 border border-rose-500/30 hover:bg-rose-500/20 transition-colors"
              title="National Cyber Financial Fraud Helpline (India)"
            >
              <PhoneCall className="w-3.5 h-3.5 text-rose-400 animate-pulse" />
              <span>1930</span>
            </a>

            {/* Language Selector */}
            <div className="relative flex items-center bg-slate-800/80 border border-slate-700 rounded-lg px-2 py-1">
              <Globe className="w-3.5 h-3.5 text-slate-400 mr-1.5" />
              <label htmlFor="language-select" className="sr-only">
                {t.languageSelectLabel}
              </label>
              <select
                id="language-select"
                value={language}
                onChange={(e) => setLanguage(e.target.value as SupportedLanguage)}
                className="bg-transparent text-xs font-medium text-slate-200 focus:outline-none cursor-pointer"
              >
                <option value="en" className="bg-slate-900 text-white">English</option>
                <option value="hi" className="bg-slate-900 text-white">हिंदी (Hindi)</option>
                <option value="gu" className="bg-slate-900 text-white">ગુજરાતી (Gujarati)</option>
              </select>
            </div>

            {/* Privacy indicator */}
            <div
              className="hidden lg:flex items-center gap-1 text-[11px] font-medium text-emerald-400 bg-emerald-950/60 border border-emerald-800/50 px-2.5 py-1 rounded-full"
              title="All processing is client-side in browser memory"
            >
              <ShieldCheck className="w-3.5 h-3.5" />
              <span>On-Device Only</span>
            </div>
          </div>
        </div>

        {/* Mobile Navigation bar */}
        <div className="flex md:hidden border-t border-slate-800 py-2 gap-1 overflow-x-auto">
          <button
            onClick={() => setActiveTab('analyze')}
            className={`px-3 py-1.5 rounded-md text-xs font-medium whitespace-nowrap ${
              activeTab === 'analyze'
                ? 'bg-slate-800 text-teal-400 border border-slate-700'
                : 'text-slate-300'
            }`}
          >
            {t.analyzeNow}
          </button>
          <button
            onClick={() => setActiveTab('demolab')}
            className={`px-3 py-1.5 rounded-md text-xs font-medium whitespace-nowrap ${
              activeTab === 'demolab'
                ? 'bg-slate-800 text-teal-400 border border-slate-700'
                : 'text-slate-300'
            }`}
          >
            Demo Lab (7)
          </button>
          <button
            onClick={() => setActiveTab('whatchanged')}
            className={`px-3 py-1.5 rounded-md text-xs font-medium whitespace-nowrap ${
              activeTab === 'whatchanged'
                ? 'bg-slate-800 text-teal-400 border border-slate-700'
                : 'text-slate-300'
            }`}
          >
            What Changed?
          </button>
          <button
            onClick={() => setActiveTab('guide')}
            className={`px-3 py-1.5 rounded-md text-xs font-medium whitespace-nowrap ${
              activeTab === 'guide'
                ? 'bg-slate-800 text-teal-400 border border-slate-700'
                : 'text-slate-300'
            }`}
          >
            Safety Guide
          </button>
        </div>
      </div>
    </header>
  );
};
