import React, { useState } from 'react';
import {
  ShieldAlert,
  ShieldCheck,
  AlertTriangle,
  Info,
  Volume2,
  VolumeX,
  FileSearch,
  ArrowRight,
  ExternalLink,
  ChevronDown,
  ChevronUp,
  CheckCircle2,
  Lock,
} from 'lucide-react';
import { AnalysisResult, RiskLevel } from '../types/index.ts';
import { useTranslation } from '../i18n/LanguageContext.tsx';

interface AnalysisResultCardProps {
  result: AnalysisResult;
  onOpenExplainability: () => void;
  onOpenChecklist: () => void;
}

export const AnalysisResultCard: React.FC<AnalysisResultCardProps> = ({
  result,
  onOpenExplainability,
  onOpenChecklist,
}) => {
  const { t, language } = useTranslation();
  const [isPlayingAudio, setIsPlayingAudio] = useState<boolean>(false);
  const [isLimitationsExpanded, setIsLimitationsExpanded] = useState<boolean>(false);

  // Web Speech API text-to-speech
  const handleToggleAudio = () => {
    if (!('speechSynthesis' in window)) {
      alert('Text-to-speech is not supported by your browser.');
      return;
    }

    if (isPlayingAudio) {
      window.speechSynthesis.cancel();
      setIsPlayingAudio(false);
      return;
    }

    const narrationText = `${result.headlineVerdict}. ${result.summaryAdvice}. Recommended action: ${result.recommendedNextAction}`;
    const utterance = new SpeechSynthesisUtterance(narrationText);

    // Pick appropriate language code
    if (language === 'hi') {
      utterance.lang = 'hi-IN';
    } else if (language === 'gu') {
      utterance.lang = 'gu-IN';
    } else {
      utterance.lang = 'en-US';
    }

    utterance.rate = 0.95;
    utterance.onend = () => setIsPlayingAudio(false);
    utterance.onerror = () => setIsPlayingAudio(false);

    window.speechSynthesis.cancel(); // Clear any pending
    window.speechSynthesis.speak(utterance);
    setIsPlayingAudio(true);
  };

  // Color & Badge configuration based on RiskLevel
  const getLevelConfig = (level: RiskLevel, isCriticalOverride: boolean) => {
    switch (level) {
      case 'critical':
        return {
          badgeBg: 'bg-rose-500/20 text-rose-300 border-rose-500/50',
          cardBorder: 'border-rose-600/70',
          glow: 'shadow-rose-900/20',
          accent: 'text-rose-400',
          icon: ShieldAlert,
          label: isCriticalOverride ? 'CRITICAL OVERRIDE' : 'CRITICAL RISK',
          progressColor: 'bg-rose-500',
        };
      case 'high':
        return {
          badgeBg: 'bg-orange-500/20 text-orange-300 border-orange-500/50',
          cardBorder: 'border-orange-500/60',
          glow: 'shadow-orange-900/20',
          accent: 'text-orange-400',
          icon: AlertTriangle,
          label: 'HIGH RISK',
          progressColor: 'bg-orange-500',
        };
      case 'caution':
        return {
          badgeBg: 'bg-amber-500/20 text-amber-300 border-amber-500/50',
          cardBorder: 'border-amber-500/60',
          glow: 'shadow-amber-900/20',
          accent: 'text-amber-400',
          icon: AlertTriangle,
          label: 'CAUTION',
          progressColor: 'bg-amber-500',
        };
      case 'low':
      default:
        return {
          badgeBg: 'bg-emerald-500/20 text-emerald-300 border-emerald-500/50',
          cardBorder: 'border-emerald-600/50',
          glow: 'shadow-emerald-900/20',
          accent: 'text-emerald-400',
          icon: ShieldCheck,
          label: 'LOWER DETECTED RISK',
          progressColor: 'bg-emerald-500',
        };
    }
  };

  const config = getLevelConfig(result.riskLevel, result.isCriticalOverride);
  const IconComponent = config.icon;

  return (
    <div
      className={`bg-slate-900 border-2 ${config.cardBorder} rounded-3xl p-5 sm:p-7 shadow-2xl ${config.glow} transition-all mb-8`}
    >
      {/* Top Header: Score & Status Badge */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-5 border-b border-slate-800">
        <div className="flex items-center gap-4">
          {/* Circular or Pill Score Indicator */}
          <div className="relative flex items-center justify-center w-16 h-16 sm:w-20 sm:h-20 rounded-2xl bg-slate-950 border border-slate-700/80 shadow-inner shrink-0">
            <div className="text-center">
              <span className={`text-2xl sm:text-3xl font-black ${config.accent}`}>
                {result.riskScore}
              </span>
              <span className="block text-[10px] text-slate-400 font-bold uppercase tracking-wider">
                / 100
              </span>
            </div>
          </div>

          <div>
            <div className="flex items-center gap-2 mb-1">
              <span
                className={`inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-black uppercase tracking-wider border ${config.badgeBg}`}
              >
                <IconComponent className="w-4 h-4" />
                <span>{config.label}</span>
              </span>
              <span className="text-[11px] font-semibold text-slate-400">
                Demo Risk Indicator
              </span>
            </div>
            <h3 className="text-lg sm:text-xl font-extrabold text-white leading-tight">
              {result.headlineVerdict}
            </h3>
          </div>
        </div>

        {/* Audio narration button */}
        <div className="flex items-center gap-2 self-start sm:self-center">
          <button
            type="button"
            onClick={handleToggleAudio}
            className="inline-flex items-center gap-1.5 px-3 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-semibold border border-slate-700 transition cursor-pointer"
            title="Read results aloud"
          >
            {isPlayingAudio ? (
              <>
                <VolumeX className="w-4 h-4 text-rose-400" />
                <span>{t.stopAudio}</span>
              </>
            ) : (
              <>
                <Volume2 className="w-4 h-4 text-teal-400" />
                <span>{t.readAloud}</span>
              </>
            )}
          </button>
        </div>
      </div>

      {/* Score Progress Bar */}
      <div className="my-4">
        <div className="flex items-center justify-between text-[11px] font-semibold text-slate-400 mb-1">
          <span>0 (Low Risk)</span>
          <span>40 (High)</span>
          <span>70 (Critical)</span>
          <span>100</span>
        </div>
        <div className="w-full h-2.5 bg-slate-950 rounded-full overflow-hidden border border-slate-800">
          <div
            className={`h-full ${config.progressColor} transition-all duration-700 ease-out`}
            style={{ width: `${Math.max(4, result.riskScore)}%` }}
          />
        </div>
      </div>

      {/* Summary Advice */}
      <div className="bg-slate-950/80 rounded-2xl p-4 sm:p-5 border border-slate-800 my-4">
        <div className="text-xs font-bold text-slate-400 uppercase tracking-wider mb-1">
          Assessment Summary
        </div>
        <p className="text-sm sm:text-base text-slate-200 leading-relaxed font-medium">
          {result.summaryAdvice}
        </p>
      </div>

      {/* Strongest Indicator Callout (if any) */}
      {result.strongestIndicator && (
        <div
          className={`p-4 rounded-2xl border mb-4 ${
            result.strongestIndicator.severity === 'critical'
              ? 'bg-rose-950/40 border-rose-800/80 text-rose-200'
              : result.strongestIndicator.severity === 'high'
              ? 'bg-orange-950/40 border-orange-800/80 text-orange-200'
              : 'bg-amber-950/40 border-amber-800/80 text-amber-200'
          }`}
        >
          <div className="flex items-start gap-3">
            <AlertTriangle className="w-5 h-5 shrink-0 mt-0.5 text-current" />
            <div>
              <div className="flex items-center gap-2 mb-1">
                <span className="text-xs font-black uppercase tracking-wider">
                  Primary Warning: {result.strongestIndicator.name}
                </span>
                <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-slate-900/80 border border-current">
                  Score impact: +{result.strongestIndicator.scoreContribution}
                </span>
              </div>
              <p className="text-xs sm:text-sm font-semibold opacity-95 mb-1.5">
                "{result.strongestIndicator.evidence}"
              </p>
              <p className="text-xs text-slate-300 opacity-90 leading-relaxed">
                <strong>Why it matters:</strong> {result.strongestIndicator.whyItMatters}
              </p>
            </div>
          </div>
        </div>
      )}

      {/* Parsed QR details (if QR mode) */}
      {result.parsedUpi && (
        <div className="bg-slate-950/90 border border-slate-800 rounded-2xl p-4 mb-4">
          <div className="text-xs font-bold text-teal-400 uppercase tracking-wider mb-2 flex items-center gap-1.5">
            <Lock className="w-3.5 h-3.5" />
            <span>Decoded UPI Payment Details</span>
          </div>
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 text-xs">
            <div className="bg-slate-900/80 p-2.5 rounded-xl border border-slate-800">
              <span className="text-slate-400 block text-[11px]">Payee VPA:</span>
              <span className="font-mono font-semibold text-slate-200 break-all">
                {result.parsedUpi.payeeVpa || 'Not specified in QR'}
              </span>
            </div>
            <div className="bg-slate-900/80 p-2.5 rounded-xl border border-slate-800">
              <span className="text-slate-400 block text-[11px]">Payee Name (Self-Reported):</span>
              <span className="font-semibold text-slate-200">
                {result.parsedUpi.payeeName || 'Not specified in QR'}
              </span>
            </div>
            {result.parsedUpi.requestedAmount && (
              <div className="bg-slate-900/80 p-2.5 rounded-xl border border-slate-800">
                <span className="text-slate-400 block text-[11px]">Preset Amount:</span>
                <span className="font-bold text-teal-300 font-sans">
                  ₹ {result.parsedUpi.requestedAmount} ({result.parsedUpi.currency || 'INR'})
                </span>
              </div>
            )}
            {result.parsedUpi.transactionNote && (
              <div className="bg-slate-900/80 p-2.5 rounded-xl border border-slate-800">
                <span className="text-slate-400 block text-[11px]">Transaction Note:</span>
                <span className="font-medium text-slate-200">
                  {result.parsedUpi.transactionNote}
                </span>
              </div>
            )}
          </div>
        </div>
      )}

      {/* Parsed URL details (if URL mode) */}
      {result.parsedUrl && (
        <div className="bg-slate-950/90 border border-slate-800 rounded-2xl p-4 mb-4">
          <div className="text-xs font-bold text-teal-400 uppercase tracking-wider mb-2 flex items-center gap-1.5">
            <ExternalLink className="w-3.5 h-3.5" />
            <span>URL Structure Heuristics</span>
          </div>
          <div className="text-xs space-y-1.5">
            <div className="flex items-center gap-2">
              <span className="text-slate-400">Hostname:</span>
              <span className="font-mono text-slate-200 font-semibold">{result.parsedUrl.hostname}</span>
              {result.parsedUrl.isShortener && (
                <span className="px-2 py-0.5 rounded text-[10px] bg-amber-500/20 text-amber-300 border border-amber-500/40">
                  URL Shortener
                </span>
              )}
              {result.parsedUrl.hasLookalikeBrands && (
                <span className="px-2 py-0.5 rounded text-[10px] bg-rose-500/20 text-rose-300 border border-rose-500/40">
                  Brand Mimicry: {result.parsedUrl.brandImpersonated}
                </span>
              )}
            </div>
            {result.parsedUrl.warnings.map((w, idx) => (
              <div key={idx} className="text-amber-300/90 text-[11px] flex items-center gap-1">
                <span>•</span>
                <span>{w}</span>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Contextual Recommended Next Action */}
      <div className="bg-gradient-to-r from-teal-950/60 to-slate-900 border border-teal-500/40 rounded-2xl p-4 sm:p-5 mb-5 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
        <div>
          <span className="text-xs font-bold uppercase tracking-wider text-teal-400 block mb-1">
            {t.recommendedAction}
          </span>
          <p className="text-sm sm:text-base font-bold text-white">
            {result.recommendedNextAction}
          </p>
        </div>
        <button
          type="button"
          onClick={onOpenChecklist}
          className="px-4 py-2.5 rounded-xl bg-teal-500 hover:bg-teal-400 text-slate-950 font-bold text-xs whitespace-nowrap transition cursor-pointer shadow-md shadow-teal-500/20"
        >
          Open Safety Checklist
        </button>
      </div>

      {/* Action Footer Buttons */}
      <div className="flex flex-wrap items-center justify-between gap-3 pt-2">
        <button
          type="button"
          onClick={onOpenExplainability}
          className="inline-flex items-center gap-2 px-4 py-2.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-teal-300 text-xs sm:text-sm font-bold border border-slate-700 transition cursor-pointer"
        >
          <FileSearch className="w-4 h-4 text-teal-400" />
          <span>{t.whyThisResult} ({result.indicators.length} signals)</span>
          <ArrowRight className="w-3.5 h-3.5" />
        </button>

        {/* Accordion toggle for Unverified Limitations */}
        <button
          type="button"
          onClick={() => setIsLimitationsExpanded(!isLimitationsExpanded)}
          className="inline-flex items-center gap-1.5 text-xs text-slate-400 hover:text-slate-200 transition cursor-pointer"
        >
          <Info className="w-3.5 h-3.5 text-cyan-400" />
          <span>What this tool could not verify</span>
          {isLimitationsExpanded ? (
            <ChevronUp className="w-3.5 h-3.5" />
          ) : (
            <ChevronDown className="w-3.5 h-3.5" />
          )}
        </button>
      </div>

      {/* Expandable Limitations Section */}
      {isLimitationsExpanded && (
        <div className="mt-4 pt-4 border-t border-slate-800 text-xs text-slate-300 bg-slate-950/60 p-4 rounded-xl">
          <div className="font-bold text-slate-200 mb-2 flex items-center gap-1.5">
            <Info className="w-4 h-4 text-cyan-400" />
            <span>{t.unverifiedLimitationsTitle}</span>
          </div>
          <ul className="space-y-1.5 text-slate-400 list-disc list-inside">
            {result.unverifiedLimitations.map((lim, idx) => (
              <li key={idx}>{lim}</li>
            ))}
          </ul>
        </div>
      )}
    </div>
  );
};
