import React from 'react';
import { ShieldAlert, AlertOctagon, PhoneCall, CheckCircle, X } from 'lucide-react';
import { AnalysisResult } from '../types/index.ts';
import { useTranslation } from '../i18n/LanguageContext.tsx';

interface SafetyInterruptModalProps {
  result: AnalysisResult;
  isOpen: boolean;
  onClose: () => void;
}

export const SafetyInterruptModal: React.FC<SafetyInterruptModalProps> = ({
  result,
  isOpen,
  onClose,
}) => {
  const { t } = useTranslation();

  if (!isOpen) return null;

  const isPinScam = result.indicators.some((i) => i.id === 'PIN_TO_RECEIVE');
  const isCredentialDemand = result.indicators.some((i) => i.id === 'CREDENTIAL_DISCLOSURE');

  return (
    <div
      role="dialog"
      aria-modal="true"
      aria-labelledby="safety-interrupt-title"
      className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-sm animate-fade-in"
    >
      <div className="relative w-full max-w-xl bg-slate-900 border-2 border-rose-600 rounded-3xl p-6 sm:p-8 text-white shadow-2xl shadow-rose-950/50">
        {/* Close icon */}
        <button
          onClick={onClose}
          aria-label="Close Safety Alert"
          className="absolute top-5 right-5 text-slate-400 hover:text-white p-1 rounded-lg hover:bg-slate-800 transition cursor-pointer"
        >
          <X className="w-5 h-5" />
        </button>

        {/* Header Icon & Title */}
        <div className="flex items-center gap-3.5 mb-5">
          <div className="w-12 h-12 rounded-2xl bg-rose-500/20 text-rose-400 border border-rose-500/40 flex items-center justify-center shrink-0">
            <AlertOctagon className="w-7 h-7 stroke-[2.5]" />
          </div>
          <div>
            <span className="text-[11px] font-black uppercase tracking-widest text-rose-400 block mb-0.5">
              PausePay Safety Interrupt
            </span>
            <h2 id="safety-interrupt-title" className="text-xl sm:text-2xl font-black text-white">
              {isPinScam
                ? t.safetyInterruptHeading
                : isCredentialDemand
                ? 'STOP — Never Disclose Your UPI PIN'
                : 'PAUSE — High Fraud Risk Detected'}
            </h2>
          </div>
        </div>

        {/* Explanation message */}
        <p className="text-sm sm:text-base text-rose-100/90 leading-relaxed font-medium mb-6 bg-rose-950/40 border border-rose-900/60 p-4 rounded-2xl">
          {isPinScam
            ? 'In UPI, you NEVER need to enter your PIN or scan a QR code to RECEIVE money. Entering your PIN will instantly DEBIT money from your bank account.'
            : isCredentialDemand
            ? 'No legitimate bank official, merchant, or support agent will EVER ask you to share your UPI PIN or OTP over phone, chat, or text.'
            : result.summaryAdvice}
        </p>

        {/* 3 Action Steps */}
        <div className="space-y-3 mb-6">
          <div className="text-xs font-bold uppercase tracking-wider text-slate-400">
            Immediate Action Required:
          </div>

          <div className="flex items-start gap-3 bg-slate-950/60 p-3.5 rounded-xl border border-slate-800">
            <div className="w-6 h-6 rounded-full bg-rose-500/20 text-rose-400 flex items-center justify-center font-bold text-xs shrink-0 mt-0.5">
              1
            </div>
            <div className="text-xs sm:text-sm text-slate-200">
              <strong className="text-white block mb-0.5">Do Not Authorize or Share</strong>
              Refuse the payment request, do not enter your UPI PIN, and do not share any OTP.
            </div>
          </div>

          <div className="flex items-start gap-3 bg-slate-950/60 p-3.5 rounded-xl border border-slate-800">
            <div className="w-6 h-6 rounded-full bg-amber-500/20 text-amber-400 flex items-center justify-center font-bold text-xs shrink-0 mt-0.5">
              2
            </div>
            <div className="text-xs sm:text-sm text-slate-200">
              <strong className="text-white block mb-0.5">Independent Verification</strong>
              Open your official banking app directly from your phone home screen to check balances or pending issues. Never use contact numbers or links provided in the suspicious message.
            </div>
          </div>

          <div className="flex items-start gap-3 bg-slate-950/60 p-3.5 rounded-xl border border-slate-800">
            <div className="w-6 h-6 rounded-full bg-teal-500/20 text-teal-400 flex items-center justify-center font-bold text-xs shrink-0 mt-0.5">
              3
            </div>
            <div className="text-xs sm:text-sm text-slate-200">
              <strong className="text-white block mb-0.5">If Money Was Already Deducted</strong>
              Immediately contact your bank branch and dial <span className="text-rose-400 font-bold">1930</span> (Indian Cyber Financial Fraud Helpline) or report to <span className="text-teal-300 font-bold">cybercrime.gov.in</span>.
            </div>
          </div>
        </div>

        {/* Bottom Actions */}
        <div className="flex flex-col sm:flex-row items-center justify-between gap-3 pt-2">
          <a
            href="tel:1930"
            className="w-full sm:w-auto inline-flex items-center justify-center gap-2 px-4 py-2.5 rounded-xl bg-rose-600 hover:bg-rose-500 text-white font-bold text-xs transition"
          >
            <PhoneCall className="w-3.5 h-3.5" />
            <span>Call Helpline 1930</span>
          </a>

          <button
            type="button"
            onClick={onClose}
            className="w-full sm:w-auto px-6 py-2.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-100 font-bold text-xs sm:text-sm border border-slate-700 transition cursor-pointer"
          >
            {t.safetyInterruptClose}
          </button>
        </div>
      </div>
    </div>
  );
};
