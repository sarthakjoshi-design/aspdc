import React from 'react';
import { ShieldCheck, PhoneCall, ExternalLink, Heart } from 'lucide-react';
import { useTranslation } from '../i18n/LanguageContext.tsx';

export const Footer: React.FC = () => {
  const { t } = useTranslation();

  return (
    <footer className="bg-slate-950 border-t border-slate-800 text-slate-400 py-10 px-4 sm:px-6 lg:px-8 text-xs">
      <div className="max-w-7xl mx-auto">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8 mb-8 pb-8 border-b border-slate-800">
          {/* Col 1: Brand & Tagline */}
          <div className="md:col-span-2">
            <div className="flex items-center gap-2 mb-2">
              <span className="font-black text-lg text-white tracking-tight">PausePay</span>
              <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-teal-500/20 text-teal-300 border border-teal-500/30">
                Stop. Verify. Then Pay.
              </span>
            </div>
            <p className="text-slate-400 leading-relaxed max-w-md mb-4 text-xs">
              Privacy-first, intent-aware UPI fraud interrupter. Evaluates suspicious payment messages, collect traps, QR payloads, and phishing links locally before you send money.
            </p>
            <div className="flex items-center gap-2 text-[11px] text-emerald-400">
              <ShieldCheck className="w-4 h-4" />
              <span>Zero-Telemetry · 100% Client-Side Processing</span>
            </div>
          </div>

          {/* Col 2: Emergency Response */}
          <div>
            <div className="font-bold text-white uppercase tracking-wider text-[11px] mb-3">
              Cyber Fraud Helpline
            </div>
            <ul className="space-y-2">
              <li>
                <a
                  href="tel:1930"
                  className="inline-flex items-center gap-1.5 text-rose-400 hover:text-rose-300 font-semibold"
                >
                  <PhoneCall className="w-3.5 h-3.5" />
                  <span>Dial 1930 (Helpline)</span>
                </a>
              </li>
              <li>
                <a
                  href="https://cybercrime.gov.in/"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="inline-flex items-center gap-1.5 text-slate-300 hover:text-white"
                >
                  <span>National Cyber Crime Portal</span>
                  <ExternalLink className="w-3 h-3" />
                </a>
              </li>
              <li className="text-[11px] text-slate-500">
                Operated by Indian Cyber Crime Coordination Centre (I4C), MHA
              </li>
            </ul>
          </div>

          {/* Col 3: Hackathon Prototype Notice */}
          <div>
            <div className="font-bold text-white uppercase tracking-wider text-[11px] mb-3">
              Prototype Integrity
            </div>
            <p className="text-[11px] text-slate-400 leading-relaxed mb-2">
              Built for hackathon demonstration using sample synthetic data. Does not connect to live banking networks or store payment credentials.
            </p>
            <p className="text-[11px] text-slate-500">
              Low detected risk does not prove sender authenticity. Always verify payees independently.
            </p>
          </div>
        </div>

        {/* Bottom bar */}
        <div className="flex flex-col sm:flex-row items-center justify-between gap-4 text-[11px] text-slate-500">
          <div>
            PausePay Prototype — Stop Fraud Before Payment. Made for national hackathon competition.
          </div>
          <div className="flex items-center gap-4">
            <span>Client-side sandbox</span>
            <span>•</span>
            <span>No external AI key required</span>
            <span>•</span>
            <span>NPCI Guidelines Compliant</span>
          </div>
        </div>
      </div>
    </footer>
  );
};
