import React, { useState } from 'react';
import { Play, Sparkles, ShieldAlert, ShieldCheck, AlertTriangle, ArrowRight, CheckCircle2, RotateCcw } from 'lucide-react';
import { DEMO_SCENARIOS } from '../engine/scenarios.ts';
import { DemoScenario, AnalysisInput, AnalysisResult } from '../types/index.ts';
import { evaluateRisk } from '../engine/riskEngine.ts';
import { useTranslation } from '../i18n/LanguageContext.tsx';

interface DemoLabProps {
  onLoadIntoAnalyzer: (input: AnalysisInput) => void;
}

export const DemoLab: React.FC<DemoLabProps> = ({ onLoadIntoAnalyzer }) => {
  const { t } = useTranslation();
  const [selectedScenario, setSelectedScenario] = useState<DemoScenario>(DEMO_SCENARIOS[1]); // Default to Cashback scam
  const [liveResult, setLiveResult] = useState<AnalysisResult>(
    evaluateRisk(DEMO_SCENARIOS[1].input)
  );

  const handleSelectScenario = (scenario: DemoScenario) => {
    setSelectedScenario(scenario);
    // Real calculation through engine
    const res = evaluateRisk(scenario.input);
    setLiveResult(res);
  };

  const handleRunInMainAnalyzer = (scenario: DemoScenario) => {
    onLoadIntoAnalyzer(scenario.input);
  };

  return (
    <div className="bg-slate-900 border border-slate-800 rounded-3xl p-4 sm:p-7 shadow-2xl mb-8">
      {/* Header */}
      <div className="mb-6 pb-4 border-b border-slate-800 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
        <div>
          <div className="flex items-center gap-2 mb-1">
            <Sparkles className="w-5 h-5 text-teal-400" />
            <h2 className="text-xl sm:text-2xl font-black text-white">
              {t.demoLabTitle}
            </h2>
            <span className="text-[10px] uppercase font-bold tracking-wider px-2 py-0.5 rounded-full bg-teal-500/20 text-teal-300 border border-teal-500/30">
              7 Test Vectors
            </span>
          </div>
          <p className="text-xs sm:text-sm text-slate-300 leading-relaxed">
            {t.demoLabSubtitle}
          </p>
        </div>

        {/* Fast jump buttons for judges */}
        <div className="flex items-center gap-2 shrink-0">
          <button
            onClick={() => handleSelectScenario(DEMO_SCENARIOS[0])}
            className="text-xs font-semibold px-3 py-1.5 rounded-xl bg-emerald-950/60 text-emerald-300 border border-emerald-700/50 hover:bg-emerald-900/60 transition cursor-pointer"
          >
            Jump to Legitimate
          </button>
          <button
            onClick={() => handleSelectScenario(DEMO_SCENARIOS[1])}
            className="text-xs font-semibold px-3 py-1.5 rounded-xl bg-rose-950/60 text-rose-300 border border-rose-700/50 hover:bg-rose-900/60 transition cursor-pointer"
          >
            Jump to Critical PIN
          </button>
        </div>
      </div>

      {/* Main Grid: Left side scenario list, Right side live evaluation */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Scenario List (5 cols) */}
        <div className="lg:col-span-5 space-y-2.5">
          <label className="block text-xs font-bold uppercase tracking-wider text-slate-400 mb-1">
            Pre-Configured Scenarios:
          </label>
          {DEMO_SCENARIOS.map((scenario, index) => {
            const isSelected = selectedScenario.id === scenario.id;
            return (
              <button
                key={scenario.id}
                onClick={() => handleSelectScenario(scenario)}
                className={`w-full text-left p-3.5 rounded-2xl border transition-all cursor-pointer ${
                  isSelected
                    ? 'bg-slate-950 border-teal-500 shadow-lg shadow-teal-500/10'
                    : 'bg-slate-950/50 border-slate-800 hover:border-slate-700'
                }`}
              >
                <div className="flex items-center justify-between gap-2 mb-1">
                  <span className="text-xs font-black text-white flex items-center gap-2">
                    <span className="w-5 h-5 rounded-full bg-slate-800 text-slate-300 text-[10px] flex items-center justify-center font-bold">
                      {index + 1}
                    </span>
                    <span>{scenario.title}</span>
                  </span>
                  <span
                    className={`text-[10px] font-bold px-2 py-0.5 rounded-full border ${
                      scenario.type.includes('Critical') || scenario.type.includes('Trap')
                        ? 'bg-rose-500/20 text-rose-300 border-rose-500/40'
                        : scenario.type.includes('Legitimate')
                        ? 'bg-emerald-500/20 text-emerald-300 border-emerald-500/40'
                        : 'bg-amber-500/20 text-amber-300 border-amber-500/40'
                    }`}
                  >
                    {scenario.type}
                  </span>
                </div>
                <p className="text-[11px] text-slate-400 line-clamp-1 ml-7">
                  {scenario.description}
                </p>
              </button>
            );
          })}
        </div>

        {/* Live Scenario Inspector (7 cols) */}
        <div className="lg:col-span-7 bg-slate-950 border border-slate-800 rounded-2xl p-5 flex flex-col justify-between">
          <div>
            {/* Scenario Header */}
            <div className="flex items-start justify-between gap-3 mb-4 pb-3 border-b border-slate-800">
              <div>
                <span className="text-[10px] font-bold uppercase tracking-wider text-teal-400">
                  Scenario Details
                </span>
                <h3 className="text-lg font-black text-white">{selectedScenario.title}</h3>
                <p className="text-xs text-slate-400 mt-0.5">{selectedScenario.description}</p>
              </div>

              {/* Live Calculated Score */}
              <div className="text-right shrink-0">
                <div
                  className={`text-2xl font-black ${
                    liveResult.riskLevel === 'critical'
                      ? 'text-rose-400'
                      : liveResult.riskLevel === 'high'
                      ? 'text-orange-400'
                      : liveResult.riskLevel === 'caution'
                      ? 'text-amber-400'
                      : 'text-emerald-400'
                  }`}
                >
                  {liveResult.riskScore}
                  <span className="text-xs text-slate-500 font-semibold">/100</span>
                </div>
                <span
                  className={`inline-block text-[10px] font-black uppercase tracking-wider px-2 py-0.5 rounded-full border ${
                    liveResult.riskLevel === 'critical'
                      ? 'bg-rose-500/20 text-rose-300 border-rose-500/40'
                      : liveResult.riskLevel === 'high'
                      ? 'bg-orange-500/20 text-orange-300 border-orange-500/40'
                      : liveResult.riskLevel === 'caution'
                      ? 'bg-amber-500/20 text-amber-300 border-amber-500/40'
                      : 'bg-emerald-500/20 text-emerald-300 border-emerald-500/40'
                  }`}
                >
                  {liveResult.riskLevel}
                </span>
              </div>
            </div>

            {/* Input Payload Preview */}
            <div className="bg-slate-900 rounded-xl p-3 border border-slate-800 mb-4">
              <span className="text-[10px] font-bold uppercase tracking-wider text-slate-400 block mb-1">
                Raw Input Delivered to Risk Engine:
              </span>
              <p className="text-xs font-mono text-slate-200 break-words whitespace-pre-wrap leading-relaxed">
                {selectedScenario.input.text || selectedScenario.input.url || selectedScenario.input.qrPayload}
              </p>
              {selectedScenario.input.qrPayload && (
                <div className="mt-2 text-[11px] text-teal-300 font-mono bg-slate-950 p-2 rounded border border-slate-800">
                  QR Payload: {selectedScenario.input.qrPayload}
                </div>
              )}
            </div>

            {/* Warning Indicators Detected */}
            <div className="mb-4">
              <span className="text-[11px] font-bold uppercase tracking-wider text-slate-400 block mb-2">
                Engine Verdict & Signals ({liveResult.indicators.length}):
              </span>
              <div className="space-y-1.5 max-h-48 overflow-y-auto pr-1">
                {liveResult.indicators.length === 0 ? (
                  <div className="text-xs text-emerald-300/90 bg-emerald-950/30 border border-emerald-800/40 p-2.5 rounded-xl font-medium flex items-center gap-2">
                    <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
                    <span>Ordinary payment behavior — no suspicious signals detected.</span>
                  </div>
                ) : (
                  liveResult.indicators.map((ind) => (
                    <div
                      key={ind.id}
                      className="p-2.5 rounded-xl bg-slate-900 border border-slate-800 text-xs flex items-center justify-between gap-2"
                    >
                      <div>
                        <div className="font-bold text-slate-200">{ind.name}</div>
                        <div className="text-[11px] text-slate-400 font-mono line-clamp-1">
                          "{ind.evidence}"
                        </div>
                      </div>
                      <span className="text-[11px] font-mono px-2 py-0.5 rounded bg-slate-800 text-teal-300 shrink-0">
                        {ind.severity === 'critical' ? 'Override' : `+${ind.scoreContribution}`}
                      </span>
                    </div>
                  ))
                )}
              </div>
            </div>

            {/* Key Learning Note */}
            <div className="bg-teal-950/30 border border-teal-800/40 rounded-xl p-3 text-xs text-teal-200/90 mb-4">
              <strong className="text-teal-300 block mb-0.5">Judge Takeaway:</strong>
              {selectedScenario.keyLearning}
            </div>
          </div>

          {/* Action to load into full interactive analyzer workspace */}
          <div className="pt-3 border-t border-slate-800 flex items-center justify-between gap-3">
            <span className="text-xs text-slate-400">
              Want to edit this text and re-test?
            </span>
            <button
              onClick={() => handleRunInMainAnalyzer(selectedScenario)}
              className="px-4 py-2 rounded-xl bg-teal-500 hover:bg-teal-400 text-slate-950 font-bold text-xs flex items-center gap-1.5 transition cursor-pointer shadow-md shadow-teal-500/20"
            >
              <span>Load in Workspace</span>
              <ArrowRight className="w-3.5 h-3.5" />
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
