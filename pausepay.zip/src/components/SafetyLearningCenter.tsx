import React, { useState } from 'react';
import {
  BookOpen,
  CheckSquare,
  Square,
  AlertTriangle,
  PhoneCall,
  ExternalLink,
  ShieldCheck,
  HelpCircle,
  QrCode,
  Lock,
  Smartphone,
  Eye,
} from 'lucide-react';
import { useTranslation } from '../i18n/LanguageContext.tsx';

interface Lesson {
  id: string;
  title: string;
  icon: React.ElementType;
  summary: string;
  details: string;
  ruleOfThumb: string;
}

const LESSONS: Lesson[] = [
  {
    id: 'lesson_pin_secret',
    title: 'The Golden Rule of UPI PIN',
    icon: Lock,
    summary: 'A UPI PIN is used strictly to DEBIT money from your bank account.',
    details:
      'You NEVER need to enter your UPI PIN, scan a QR code, or approve a collect request to RECEIVE funds. Whenever someone promises to deposit cashback or money into your account and asks you to enter your PIN, it is 100% guaranteed to be a fraud trap.',
    ruleOfThumb: 'Entering PIN = Money LEAVES your account. Receiving money requires ZERO PIN entry.',
  },
  {
    id: 'lesson_qr_codes',
    title: 'QR Codes Demystified',
    icon: QrCode,
    summary: 'Scanning a QR code ALWAYS initiates an outgoing transfer from you to someone else.',
    details:
      'Scammers often send a QR code saying "Scan this to claim ₹10,000 lottery or OLX payment." In reality, the QR code has a hidden "upi://pay" command that requests money FROM you. Scanning it will open your payment app with a debit request.',
    ruleOfThumb: 'Never scan a QR code sent by a buyer or caller claiming to pay you.',
  },
  {
    id: 'lesson_rewards_cashback',
    title: 'Fake Cashback & Lottery Traps',
    icon: AlertTriangle,
    summary: 'Unsolicited prize messages exploit excitement to bypass your caution.',
    details:
      'Legitimate cashback from apps like Google Pay or PhonePe is deposited directly to your bank account via UPI without requiring you to click links or enter credentials. If a message asks you to claim a prize within 5 minutes, pause and recognize the trap.',
    ruleOfThumb: 'Genuine cashback happens automatically in the background. It never demands PIN entry.',
  },
  {
    id: 'lesson_urgent_kyc_threats',
    title: 'Urgent Account Suspension & KYC Panic',
    icon: Smartphone,
    summary: 'Threatening that your SIM, bank account, or power will be cut in 10 minutes is a panic tactic.',
    details:
      'Banks and utility companies give written notices weeks in advance through registered post and within your official banking app. Scammers create fake urgency so you panic and click their phishing link without verifying.',
    ruleOfThumb: 'Never tap the link or call the number in the SMS. Open your official banking app independently.',
  },
  {
    id: 'lesson_remote_access',
    title: 'Remote-Access & Screen-Sharing Danger',
    icon: Eye,
    summary: 'Scammers pose as support agents and ask you to install AnyDesk or TeamViewer.',
    details:
      'Once installed and you share your 9-digit code, the attacker can view your phone screen in real time. When you open your banking app, they record your PIN and harvest SMS OTPs to drain your account within seconds.',
    ruleOfThumb: 'Never install AnyDesk, TeamViewer, or RustDesk on the instruction of any caller.',
  },
  {
    id: 'lesson_new_recipient_test',
    title: 'The ₹1 Safety Test for New Recipients',
    icon: ShieldCheck,
    summary: 'An unfamiliar UPI ID is a reason for caution, not an automatic accusation.',
    details:
      'When paying a new seller or unfamiliar number for the first time, check their verified merchant name on the payment screen. For large transfers, send a test transaction of ₹1 first and confirm receipt before sending the full amount.',
    ruleOfThumb: 'Send ₹1 first for first-time large payments to verify the recipient account.',
  },
];

export const SafetyLearningCenter: React.FC = () => {
  const { t } = useTranslation();
  const [selectedLesson, setSelectedLesson] = useState<Lesson>(LESSONS[0]);

  // Interactive Checklist State
  const [checkedItems, setCheckedItems] = useState<Record<number, boolean>>({
    0: false,
    1: false,
    2: false,
    3: false,
    4: false,
  });

  const toggleChecklist = (index: number) => {
    setCheckedItems((prev) => ({
      ...prev,
      [index]: !prev[index],
    }));
  };

  const checklistItems = [
    'I verified the payee name and UPI ID in my banking app before tapping pay.',
    'I confirmed that I am SENDING money, not being tricked into entering my PIN to receive funds.',
    'I am NOT on a phone call with someone instructing me to share my screen or install AnyDesk.',
    'I did not follow a shortened link (like bit.ly) or SMS link to arrive at this payment.',
    'If paying an unfamiliar recipient a large amount, I tested with a ₹1 transaction first.',
  ];

  const completedCount = Object.values(checkedItems).filter(Boolean).length;

  return (
    <div className="bg-slate-900 border border-slate-800 rounded-3xl p-4 sm:p-7 shadow-2xl mb-8">
      {/* Title */}
      <div className="mb-6 pb-4 border-b border-slate-800 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
        <div>
          <div className="flex items-center gap-2 mb-1">
            <BookOpen className="w-5 h-5 text-teal-400" />
            <h2 className="text-xl sm:text-2xl font-black text-white">
              {t.safetyGuideTitle}
            </h2>
          </div>
          <p className="text-xs sm:text-sm text-slate-300">
            Official fraud-prevention principles, interactive pre-payment checklist, and emergency response.
          </p>
        </div>

        {/* 1930 Button */}
        <a
          href="tel:1930"
          className="inline-flex items-center gap-2 px-4 py-2 rounded-xl bg-rose-600 hover:bg-rose-500 text-white font-bold text-xs shadow-md transition self-start sm:self-center shrink-0"
        >
          <PhoneCall className="w-4 h-4 animate-pulse" />
          <span>Helpline 1930</span>
        </a>
      </div>

      {/* Section 1: Interactive Pre-Payment Checklist */}
      <div className="bg-slate-950 border border-slate-800 rounded-2xl p-5 mb-8">
        <div className="flex items-center justify-between mb-3">
          <div className="flex items-center gap-2">
            <CheckSquare className="w-5 h-5 text-teal-400" />
            <h3 className="text-base sm:text-lg font-bold text-white">
              {t.safetyChecklistTitle}
            </h3>
          </div>
          <span className="text-xs font-semibold px-2.5 py-0.5 rounded-full bg-teal-500/20 text-teal-300 border border-teal-500/40">
            {completedCount} of 5 Verified
          </span>
        </div>
        <p className="text-xs text-slate-400 mb-4">
          Before entering your secret UPI PIN in your payment app, take 10 seconds to verify these 5 safety checkpoints:
        </p>

        <div className="space-y-2.5">
          {checklistItems.map((item, idx) => {
            const isChecked = Boolean(checkedItems[idx]);
            return (
              <div
                key={idx}
                onClick={() => toggleChecklist(idx)}
                className={`flex items-start gap-3 p-3 rounded-xl border text-xs sm:text-sm transition cursor-pointer select-none ${
                  isChecked
                    ? 'bg-emerald-950/30 border-emerald-700/60 text-emerald-200'
                    : 'bg-slate-900 border-slate-800 text-slate-300 hover:border-slate-700'
                }`}
              >
                {isChecked ? (
                  <CheckSquare className="w-4 h-4 text-emerald-400 shrink-0 mt-0.5" />
                ) : (
                  <Square className="w-4 h-4 text-slate-500 shrink-0 mt-0.5" />
                )}
                <span className={isChecked ? 'font-medium' : ''}>{item}</span>
              </div>
            );
          })}
        </div>
      </div>

      {/* Section 2: Bite-Sized Lessons Grid & Viewer */}
      <div className="mb-8">
        <h3 className="text-base font-bold text-white mb-3 flex items-center gap-2">
          <span>Core Security Lessons for Every UPI User</span>
        </h3>

        <div className="grid grid-cols-1 md:grid-cols-12 gap-5">
          {/* Lessons list */}
          <div className="md:col-span-5 space-y-2">
            {LESSONS.map((lesson) => {
              const isSelected = selectedLesson.id === lesson.id;
              const Icon = lesson.icon;
              return (
                <button
                  key={lesson.id}
                  onClick={() => setSelectedLesson(lesson)}
                  className={`w-full text-left p-3 rounded-xl border text-xs transition cursor-pointer flex items-center gap-3 ${
                    isSelected
                      ? 'bg-teal-500/10 border-teal-500 text-teal-200'
                      : 'bg-slate-950 border-slate-800 text-slate-300 hover:border-slate-700'
                  }`}
                >
                  <div className="p-2 rounded-lg bg-slate-900 border border-slate-700 text-teal-400 shrink-0">
                    <Icon className="w-4 h-4" />
                  </div>
                  <div>
                    <div className="font-bold text-slate-200">{lesson.title}</div>
                    <div className="text-[11px] text-slate-400 line-clamp-1">
                      {lesson.summary}
                    </div>
                  </div>
                </button>
              );
            })}
          </div>

          {/* Active Lesson Detail View */}
          <div className="md:col-span-7 bg-slate-950 border border-slate-800 rounded-2xl p-5 flex flex-col justify-between">
            <div>
              <div className="flex items-center gap-2.5 mb-2">
                <selectedLesson.icon className="w-5 h-5 text-teal-400" />
                <h4 className="text-lg font-black text-white">{selectedLesson.title}</h4>
              </div>
              <p className="text-xs sm:text-sm text-slate-300 leading-relaxed font-medium mb-4">
                {selectedLesson.details}
              </p>
            </div>

            <div className="bg-slate-900/90 border border-teal-500/30 rounded-xl p-3.5 text-xs text-teal-300">
              <strong className="text-white block mb-0.5">Rule of Thumb:</strong>
              {selectedLesson.ruleOfThumb}
            </div>
          </div>
        </div>
      </div>

      {/* Section 3: Official Incident Reporting Guidance */}
      <div className="bg-gradient-to-r from-rose-950/40 via-slate-950 to-slate-950 border border-rose-800/60 rounded-2xl p-5">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div>
            <div className="flex items-center gap-2 text-rose-400 font-bold text-sm mb-1">
              <AlertTriangle className="w-4 h-4" />
              <span>{t.officialHelplineTitle}</span>
            </div>
            <p className="text-xs sm:text-sm text-slate-300 leading-relaxed max-w-2xl">
              {t.officialHelplineText}
            </p>
          </div>

          <div className="flex flex-wrap items-center gap-3 shrink-0">
            <a
              href="tel:1930"
              className="inline-flex items-center gap-1.5 px-4 py-2.5 rounded-xl bg-rose-600 hover:bg-rose-500 text-white font-bold text-xs transition"
            >
              <PhoneCall className="w-4 h-4" />
              <span>Dial 1930 Helpline</span>
            </a>
            <a
              href="https://cybercrime.gov.in/"
              target="_blank"
              rel="noopener noreferrer"
              className="inline-flex items-center gap-1.5 px-4 py-2.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-teal-300 font-semibold text-xs border border-slate-700 transition"
            >
              <span>cybercrime.gov.in</span>
              <ExternalLink className="w-3.5 h-3.5" />
            </a>
          </div>
        </div>
      </div>
    </div>
  );
};
