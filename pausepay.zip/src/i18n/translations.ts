export type SupportedLanguage = 'en' | 'hi' | 'gu';

export interface TranslationDictionary {
  tagline: string;
  supportingMessage: string;
  privacyGuarantee: string;
  heroHeadline: string;
  heroSubhead: string;
  analyzeNow: string;
  tryLiveDemo: string;
  modeMessage: string;
  modeLink: string;
  modeQr: string;
  modeDetails: string;
  intentLabel: string;
  intents: Record<string, string>;
  checkRiskBtn: string;
  resetBtn: string;
  samplePlaceholderMsg: string;
  samplePlaceholderLink: string;
  samplePlaceholderQr: string;
  recipientVpaLabel: string;
  recipientNameLabel: string;
  amountLabel: string;
  firstTimeRecipientCheck: string;
  resultsTitle: string;
  riskScoreLabel: string;
  severityLabel: string;
  verdictLabel: string;
  evidenceFound: string;
  recommendedAction: string;
  whyThisResult: string;
  readAloud: string;
  stopAudio: string;
  unverifiedLimitationsTitle: string;
  safetyInterruptHeading: string;
  safetyInterruptSubhead: string;
  safetyInterruptSteps: string[];
  safetyInterruptClose: string;
  demoLabTitle: string;
  demoLabSubtitle: string;
  runAnalysisBtn: string;
  whatChangedTitle: string;
  whatChangedSubtitle: string;
  compareButton: string;
  safetyGuideTitle: string;
  safetyChecklistTitle: string;
  officialHelplineTitle: string;
  officialHelplineText: string;
  portalLinkText: string;
  languageSelectLabel: string;
}

export const TRANSLATIONS: Record<SupportedLanguage, TranslationDictionary> = {
  en: {
    tagline: 'Stop. Verify. Then Pay.',
    supportingMessage: 'One pause can prevent a costly mistake.',
    privacyGuarantee: '100% On-Device Privacy. No real payment is made, and your data never leaves this browser.',
    heroHeadline: 'Pause before you approve.',
    heroSubhead:
      'Check suspicious UPI messages, collect requests, links, and QR codes before sending money. Stop fraud before payment occurs.',
    analyzeNow: 'Analyze a Payment',
    tryLiveDemo: 'Explore Demo Scenarios',
    modeMessage: 'Analyze Message',
    modeLink: 'Analyze Link',
    modeQr: 'Check QR Code',
    modeDetails: 'Payment Details',
    intentLabel: 'What are you trying to do?',
    intents: {
      send_money: 'Send money to a merchant or person',
      receive_money: 'Receive money, cashback, or refund',
      scan_qr: 'Scan a physical or digital QR code',
      review_request: 'Review a payment or collect request',
      verify_message: 'Verify an urgent SMS, WhatsApp, or link',
      understand_instruction: 'Understand an unfamiliar instruction',
    },
    checkRiskBtn: 'Check for Risk',
    resetBtn: 'Clear & Reset',
    samplePlaceholderMsg:
      'Paste the payment message, SMS, WhatsApp text, or collect request here...\nExample: "Congratulations! You won ₹5,000. Enter your UPI PIN to claim."',
    samplePlaceholderLink: 'https://example.com/verify-payment or shortened bit.ly link',
    samplePlaceholderQr: 'Paste decoded QR payload (e.g. upi://pay?pa=merchant@upi&pn=Store&am=450)',
    recipientVpaLabel: 'Recipient UPI ID / VPA',
    recipientNameLabel: 'Recipient Display Name (Optional)',
    amountLabel: 'Amount (₹)',
    firstTimeRecipientCheck: 'This is a new or unfamiliar recipient I have not paid before',
    resultsTitle: 'Safety Risk Assessment',
    riskScoreLabel: 'Risk Score',
    severityLabel: 'Risk Category',
    verdictLabel: 'Safety Verdict',
    evidenceFound: 'Observable Evidence Detected',
    recommendedAction: 'Recommended Next Action',
    whyThisResult: 'Why this result? (Detailed Breakdown)',
    readAloud: 'Listen (Audio)',
    stopAudio: 'Stop Audio',
    unverifiedLimitationsTitle: 'Important Limitations & What Was Not Verified',
    safetyInterruptHeading: 'STOP — Do Not Enter Your UPI PIN',
    safetyInterruptSubhead:
      'A critical fraud pattern was detected. Entering your PIN will debit money from your account, not credit it.',
    safetyInterruptSteps: [
      'Do not approve the transaction or disclose your UPI PIN or OTP to anyone.',
      'Remember: UPI PIN is ONLY entered to send money. You NEVER need a PIN to receive funds.',
      'If you have already sent money, call the National Cyber Financial Helpline 1930 immediately.',
    ],
    safetyInterruptClose: 'I Understand — Review Analysis',
    demoLabTitle: 'Judge-Ready Demo Lab',
    demoLabSubtitle:
      'Experience how PausePay analyzes legitimate transactions and real-world fraud scenarios through the transparent engine.',
    runAnalysisBtn: 'Run Analysis',
    whatChangedTitle: '"What Changed?" Fraud Replay Simulator',
    whatChangedSubtitle:
      'Compare how subtle wording changes in scam messages alter risk indicators, urgency levels, and fraud scores.',
    compareButton: 'Compare Messages',
    safetyGuideTitle: 'UPI Fraud Prevention Guide & Pre-Payment Checklist',
    safetyChecklistTitle: '5-Step Pre-Payment Verification Checklist',
    officialHelplineTitle: 'Victim of Financial Cyber Fraud?',
    officialHelplineText:
      'If money was unauthorizedly debited, immediately report to your bank and call the Government of India Cyber Financial Fraud Helpline at 1930.',
    portalLinkText: 'National Cyber Crime Reporting Portal (cybercrime.gov.in)',
    languageSelectLabel: 'Language',
  },

  hi: {
    tagline: 'रुको। जांचो। फिर भुगतान करो।',
    supportingMessage: 'एक छोटा सा विराम भारी वित्तीय नुकसान से बचा सकता है।',
    privacyGuarantee: '100% डिवाइस पर निजी। कोई वास्तविक भुगतान नहीं होता और आपका डेटा इस ब्राउज़र से बाहर नहीं जाता।',
    heroHeadline: 'भुगतान स्वीकार करने से पहले एक पल रुकें।',
    heroSubhead:
      'पैसे भेजने से पहले संदिग्ध यूपीआई संदेशों, कलेक्ट अनुरोधों, लिंक और क्यूआर कोड की तुरंत जांच करें।',
    analyzeNow: 'संदेश की जांच करें',
    tryLiveDemo: 'डेमो परिदृश्य देखें',
    modeMessage: 'संदेश जांचें',
    modeLink: 'लिंक जांचें',
    modeQr: 'क्यूआर कोड जांचें',
    modeDetails: 'भुगतान विवरण',
    intentLabel: 'आप क्या करना चाहते हैं?',
    intents: {
      send_money: 'दुकानदार या व्यक्ति को पैसे भेजना',
      receive_money: 'पैसे, कैशबैक या रिफंड प्राप्त करना',
      scan_qr: 'क्यूआर कोड स्कैन करना',
      review_request: 'पेमेंट या कलेक्ट रिक्वेस्ट देखना',
      verify_message: 'संदिग्ध एसएमएस या लिंक की पुष्टि करना',
      understand_instruction: 'अपरिचित निर्देश को समझना',
    },
    checkRiskBtn: 'जोखिम की जांच करें',
    resetBtn: 'साफ़ करें',
    samplePlaceholderMsg:
      'यहां भुगतान से संबंधित संदेश या एसएमएस पेस्ट करें...\nउदाहरण: "बधाई हो! आपने ₹5,000 जीते हैं। प्राप्त करने के लिए अपना यूपीआई पिन दर्ज करें।"',
    samplePlaceholderLink: 'https://example.com/verify या छोटा लिंक पेस्ट करें',
    samplePlaceholderQr: 'क्यूआर कोड पेलोड दर्ज करें (उदा. upi://pay?pa=shop@upi)',
    recipientVpaLabel: 'प्राप्तकर्ता का यूपीआई आईडी',
    recipientNameLabel: 'प्राप्तकर्ता का नाम (वैकल्पिक)',
    amountLabel: 'राशि (₹)',
    firstTimeRecipientCheck: 'यह एक नया या अपरिचित प्राप्तकर्ता है जिसे पहले कभी भुगतान नहीं किया',
    resultsTitle: 'सुरक्षा जोखिम मूल्यांकन',
    riskScoreLabel: 'जोखिम स्कोर',
    severityLabel: 'जोखिम स्तर',
    verdictLabel: 'सुरक्षा निष्कर्ष',
    evidenceFound: 'पहचाने गए चेतावनी संकेत',
    recommendedAction: 'सुरक्षित अगला कदम',
    whyThisResult: 'यह परिणाम क्यों? (विस्तृत विवरण)',
    readAloud: 'सुनें (ऑडियो)',
    stopAudio: 'ऑडियो रोकें',
    unverifiedLimitationsTitle: 'महत्वपूर्ण सीमाएं और क्या सत्यापित नहीं किया गया',
    safetyInterruptHeading: 'रुकें — अपना यूपीआई पिन कभी दर्ज न करें',
    safetyInterruptSubhead:
      'गंभीर धोखाधड़ी का संकेत मिला है। पिन दर्ज करने से आपके बैंक खाते से पैसे कटेंगे, पैसे मिलेंगे नहीं।',
    safetyInterruptSteps: [
      'लेनदेन को तुरंत अस्वीकार करें और अपना यूपीआई पिन या ओटीपी किसी को न बताएं।',
      'याद रखें: यूपीआई पिन केवल पैसे भेजने के लिए होता है, पैसे प्राप्त करने के लिए कभी नहीं।',
      'यदि धोखाधड़ी हो चुकी है, तो तुरंत राष्ट्रीय साइबर हेल्पलाइन 1930 पर कॉल करें।',
    ],
    safetyInterruptClose: 'मैं समझ गया — परिणाम देखें',
    demoLabTitle: 'जज डेमो लैब (Demo Lab)',
    demoLabSubtitle:
      'देखें कि पॉजपे वास्तविक घोटालों और सामान्य भुगतानों का पारदर्शी तरीके से कैसे विश्लेषण करता है।',
    runAnalysisBtn: 'विश्लेषण चलाएं',
    whatChangedTitle: '"क्या बदला?" फ्रॉड सिम्युलेटर',
    whatChangedSubtitle:
      'देखें कि शब्दों और धमकियों में बदलाव से धोखाधड़ी का स्कोर और चेतावनी संकेत कैसे बदलते हैं।',
    compareButton: 'संदेशों की तुलना करें',
    safetyGuideTitle: 'यूपीआई सुरक्षा मार्गदर्शिका और पूर्व-भुगतान चेकलिस्ट',
    safetyChecklistTitle: 'भुगतान से पहले 5-चरणीय सुरक्षा चेकलिस्ट',
    officialHelplineTitle: 'साइबर वित्तीय धोखाधड़ी के शिकार हुए?',
    officialHelplineText:
      'यदि खाते से अनधिकृत रूप से पैसे कट गए हैं, तो तुरंत अपने बैंक को सूचित करें और 1930 पर कॉल करें।',
    portalLinkText: 'राष्ट्रीय साइबर अपराध रिपोर्टिंग पोर्टल (cybercrime.gov.in)',
    languageSelectLabel: 'भाषा',
  },

  gu: {
    tagline: 'રોકાઓ. ચકાસો. પછી ચૂકવો.',
    supportingMessage: 'એક નાનકડો વિરામ મોટા આર્થિક નુકસાનથી બચાવી શકે છે.',
    privacyGuarantee: '100% ડિવાઇસ પર ખાનગી. કોઈ વાસ્તવિક ચુકવણી થતી નથી અને તમારો ડેટા સુરક્ષિત રહે છે.',
    heroHeadline: 'ચુકવણી મંજૂર કરતા પહેલાં રોકાઓ.',
    heroSubhead:
      'પૈસા મોકલતા પહેલાં શંકાસ્પદ યુપીઆઈ મેસેજ, કલેક્ટ રિક્વેસ્ટ, લિંક્સ અને ક્યૂઆર કોડની ચકાસણી કરો.',
    analyzeNow: 'ચુકવણી ચકાસો',
    tryLiveDemo: 'લાઈવ ડેમો જુઓ',
    modeMessage: 'મેસેજ ચકાસો',
    modeLink: 'લિંક ચકાસો',
    modeQr: 'ક્યૂઆર કોડ ચકાસો',
    modeDetails: 'ચુકવણી વિગતો',
    intentLabel: 'તમે શું કરવા માંગો છો?',
    intents: {
      send_money: 'વેપારી કે વ્યક્તિને પૈસા મોકલવા',
      receive_money: 'પૈસા, કેશબેક કે રિફંડ મેળવવું',
      scan_qr: 'ક્યૂઆર કોડ સ્કેન કરવો',
      review_request: 'પેમેન્ટ રિક્વેસ્ટ તપાસવી',
      verify_message: 'શંકાસ્પદ એસએમએસ કે લિંક ચકાસવી',
      understand_instruction: 'નવી સૂચના સમજવી',
    },
    checkRiskBtn: 'જોખમ ચકાસો',
    resetBtn: 'સાફ કરો',
    samplePlaceholderMsg:
      'પેમેન્ટ સંબંધિત સંદેશ અથવા એસએમએસ અહીં પેસ્ટ કરો...\nઉદાહરણ: "અભિનંદન! તમે ₹5,000 જીત્યા છો. મેળવવા માટે યુપીઆઈ પિન દાખલ કરો."',
    samplePlaceholderLink: 'https://example.com/verify લિંક પેસ્ટ કરો',
    samplePlaceholderQr: 'ક્યૂઆર પેલોડ દાખલ કરો (દા.ત. upi://pay?pa=shop@upi)',
    recipientVpaLabel: 'પ્રાપ્તકર્તાનું યુપીઆઈ આઈડી',
    recipientNameLabel: 'પ્રાપ્તકર્તાનું નામ (વૈકલ્પિક)',
    amountLabel: 'રકમ (₹)',
    firstTimeRecipientCheck: 'આ એક નવા પ્રાપ્તકર્તા છે જેમને મેં પહેલાં ક્યારેય ચુકવણી કરી નથી',
    resultsTitle: 'સુરક્ષા જોખમ મૂલ્યાંકન',
    riskScoreLabel: 'જોખમ સ્કોર',
    severityLabel: 'જોખમ શ્રેણી',
    verdictLabel: 'સુરક્ષા તારણ',
    evidenceFound: 'શોધાયેલા પુરાવા અને સંકેતો',
    recommendedAction: 'ભલામણ કરેલ સુરક્ષિત પગલું',
    whyThisResult: 'આ પરિણામ કેમ? (વિગતવાર સમજૂતી)',
    readAloud: 'સાંભળો (ઓડિયો)',
    stopAudio: 'ઓડિયો બંધ કરો',
    unverifiedLimitationsTitle: 'મહત્વપૂર્ણ મર્યાદાઓ અને શું ચકાસાયું નથી',
    safetyInterruptHeading: 'રોકાઓ — તમારો યુપીઆઈ પિન ક્યારેય નાખશો નહીં',
    safetyInterruptSubhead:
      'ગંભીર છેતરપિંડીનો સંકેત મળ્યો છે. પિન નાખવાથી ખાતામાંથી પૈસા કપાશે, મળશે નહીં.',
    safetyInterruptSteps: [
      'આ ચુકવણીને તરત જ રદ કરો અને તમારો પિન કે ઓટીપી કોઈને આપશો નહીં.',
      'યાદ રાખો: યુપીઆઈ પિન ફક્ત પૈસા મોકલવા માટે જ વપરાય છે, પૈસા મેળવવા માટે ક્યારેય નહીં.',
      'જો પૈસા કપાઈ ગયા હોય, તો તરત જ સાયબર હેલ્પલાઇન 1930 પર સંપર્ક કરો.',
    ],
    safetyInterruptClose: 'હું સમજી ગયો — વિશ્લેષણ જુઓ',
    demoLabTitle: 'જજ ડેમો લેબ (Demo Lab)',
    demoLabSubtitle:
      'જુઓ કે પોઝપે કેવી રીતે સામાન્ય વ્યવહારો અને વાસ્તવિક છેતરપિંડીનું પારદર્શક વિશ્લેષણ કરે છે.',
    runAnalysisBtn: 'વિશ્લેષણ કરો',
    whatChangedTitle: '"શું બદલાયું?" ફ્રોડ સિમ્યુલેટર',
    whatChangedSubtitle:
      'સંદેશના શબ્દોમાં ફેરફાર કરવાથી જોખમ સ્કોર અને ચેતવણી સંકેતો કેવી રીતે બદલાય છે તે સરખાવો.',
    compareButton: 'મેસેજ સરખાવો',
    safetyGuideTitle: 'યુપીઆઈ સુરક્ષા માર્ગદર્શિકા અને પ્રી-પેમેન્ટ ચેકલિસ્ટ',
    safetyChecklistTitle: 'ચુકવણી પહેલાં 5-પગલાંની સુરક્ષા ચેકલિસ્ટ',
    officialHelplineTitle: 'સાયબર છેતરપિંડીનો ભોગ બન્યા?',
    officialHelplineText:
      'જો ખાતામાંથી અનધિકૃત રીતે પૈસા કપાયા હોય, તો તરત જ બેંકનો સંપર્ક કરો અને 1930 ડાયલ કરો.',
    portalLinkText: 'નેશનલ સાયબર ક્રાઈમ રિપોર્ટિંગ પોર્ટલ (cybercrime.gov.in)',
    languageSelectLabel: 'ભાષા',
  },
};
